using System.Collections.Generic;
using UnityEngine;

namespace DreamHouse
{
    /// <summary>
    /// Tiny material factory with per-color caching so the runtime-built
    /// house shares materials (low draw-call overhead, no asset files needed).
    /// </summary>
    public static class Viz
    {
        static Dictionary<Color, Material> standardCache = new Dictionary<Color, Material>();
        static Dictionary<Color, Material> unlitCache = new Dictionary<Color, Material>();

        public static Material Get(Color color)
        {
            Material m;
            if (!standardCache.TryGetValue(color, out m))
            {
                Shader s = Shader.Find("Standard");
                m = new Material(s);
                m.color = color;
                m.SetFloat("_Glossiness", 0.35f);
                m.SetFloat("_Metallic", 0f);
                m.name = "Viz_" + color.GetHashCode();
                standardCache[color] = m;
            }
            return m;
        }

        /// <summary>Flat, self-illuminated look (windows, rings, screens).</summary>
        public static Material GetUnlit(Color color)
        {
            Material m;
            if (!unlitCache.TryGetValue(color, out m))
            {
                Shader s = Shader.Find("Unlit/Color");
                m = new Material(s);
                m.color = color;
                m.name = "VizUnlit_" + color.GetHashCode();
                unlitCache[color] = m;
            }
            return m;
        }

        public static void ClearCaches()
        {
            foreach (var kv in standardCache) Object.Destroy(kv.Value);
            standardCache.Clear();
            foreach (var kv in unlitCache) Object.Destroy(kv.Value);
            unlitCache.Clear();
        }
    }
}

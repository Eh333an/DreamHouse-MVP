using UnityEngine;

namespace DreamHouse
{
    /// <summary>Room names used across missions and events.</summary>
    public static class Rooms
    {
        public const string Living = "living";
        public const string Bedroom = "bedroom";
        public const string Wardrobe = "wardrobe";
    }

    /// <summary>
    /// Invisible trigger volume covering one room. Notifies GameEvents when the
    /// player walks in (used by missions).
    /// </summary>
    public class RoomZone : MonoBehaviour
    {
        public string room = Rooms.Living;

        void OnTriggerEnter(Collider other)
        {
            var body = other.GetComponentInParent<PlayerBody>();
            if (body != null)
            {
                GameEvents.RaiseRoomEntered(room);
            }
        }
    }
}

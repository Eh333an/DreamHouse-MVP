using UnityEngine;

namespace DreamHouse
{
    /// <summary>
    /// Builds the Dream House at runtime: three connected rooms (living,
    /// bedroom, wardrobe), pastel palette, furniture with colliders,
    /// always-open doorways, mission trigger zones and interaction points.
    ///
    /// All geometry is TEMPORARY placeholder (primitive diorama) per project
    /// spec — it exists to validate movement/collision/camera before real
    /// environment art is produced. No ceiling on purpose (diorama style,
    /// keeps the third-person camera free in small rooms).
    /// </summary>
    public static class HouseBuilder
    {
        public class HouseBuild
        {
            public Vector3 playerSpawn;
            public float playerYaw;
            public DecorPlacementSpot decorSpot;
            public DecorItemPickup decorItem;
            public Transform wardrobeInteract;
        }

        const float WallH = 2.4f;
        const float WallT = 0.15f;

        // palette (soft, pastel)
        static Color WallPeach = new Color(0.95f, 0.87f, 0.80f);
        static Color WallLavender = new Color(0.87f, 0.87f, 0.95f);
        static Color WallMint = new Color(0.85f, 0.93f, 0.88f);
        static Color FloorLiving = new Color(0.88f, 0.80f, 0.68f);
        static Color FloorBedroom = new Color(0.83f, 0.79f, 0.87f);
        static Color FloorWardrobe = new Color(0.85f, 0.90f, 0.82f);
        static Color Wood = new Color(0.72f, 0.60f, 0.47f);
        static Color WoodLight = new Color(0.82f, 0.72f, 0.58f);
        static Color White = new Color(0.97f, 0.96f, 0.94f);
        static Color SofaPink = new Color(0.93f, 0.78f, 0.80f);
        static Color SofaCream = new Color(0.95f, 0.90f, 0.80f);
        static Color RugMint = new Color(0.80f, 0.92f, 0.86f);
        static Color RugLavender = new Color(0.86f, 0.84f, 0.94f);
        static Color RugPink = new Color(0.94f, 0.84f, 0.88f);
        static Color BedLavender = new Color(0.76f, 0.72f, 0.88f);
        static Color PlantGreen = new Color(0.55f, 0.75f, 0.55f);
        static Color PotTerra = new Color(0.80f, 0.58f, 0.45f);
        static Color VasePink = new Color(0.90f, 0.62f, 0.68f);
        static Color Mirror = new Color(0.82f, 0.86f, 0.90f);
        static Color WardrobeWood = new Color(0.66f, 0.52f, 0.40f);
        static Color SpotYellow = new Color(0.98f, 0.90f, 0.60f);

        public static HouseBuild Build(Transform parent, DreamHouseGame game)
        {
            var house = new GameObject("House");
            house.transform.SetParent(parent, false);
            var h = house.transform;

            var result = new HouseBuild
            {
                playerSpawn = new Vector3(3f, 0.02f, 3.1f),
                playerYaw = 180f
            };

            BuildFloors(h);
            BuildWalls(h);
            BuildLiving(h, result);
            BuildBedroom(h, result);
            BuildWardrobeRoom(h, result);
            BuildZones(h);
            BuildLights(h);

            return result;
        }

        // ---------------------------------------------------------------
        static void BuildFloors(Transform h)
        {
            Box(h, "Floor_Living", new Vector3(3f, -0.05f, 2.5f), new Vector3(6f, 0.1f, 5f), FloorLiving, true);
            Box(h, "Floor_Bedroom", new Vector3(-2f, -0.05f, 2f), new Vector3(4f, 0.1f, 4f), FloorBedroom, true);
            Box(h, "Floor_Wardrobe", new Vector3(8f, -0.05f, 2f), new Vector3(4f, 0.1f, 4f), FloorWardrobe, true);

            Box(h, "Rug_Living", new Vector3(3f, 0.011f, 2.4f), new Vector3(2.4f, 0.022f, 1.8f), RugMint, false);
            Box(h, "Rug_Bedroom", new Vector3(-2f, 0.011f, 2.3f), new Vector3(2.0f, 0.022f, 1.4f), RugLavender, false);
            Box(h, "Rug_Wardrobe", new Vector3(8f, 0.011f, 2.2f), new Vector3(2.0f, 0.022f, 1.2f), RugPink, false);
        }

        static void BuildWalls(Transform h)
        {
            // outer back wall (all rooms)
            Wall(h, new Vector3(3f, WallH / 2, -WallT / 2), new Vector3(14.3f, WallH, WallT), WallPeach);
            // living front
            Wall(h, new Vector3(3f, WallH / 2, 5f + WallT / 2), new Vector3(6.15f, WallH, WallT), WallPeach);
            // bedroom left outer
            Wall(h, new Vector3(-4f - WallT / 2, WallH / 2, 2f), new Vector3(WallT, WallH, 4.15f), WallLavender);
            // bedroom front
            Wall(h, new Vector3(-2f - WallT / 4, WallH / 2, 4f + WallT / 2), new Vector3(4.15f, WallH, WallT), WallLavender);
            // wardrobe right outer
            Wall(h, new Vector3(10f + WallT / 2, WallH / 2, 2f), new Vector3(WallT, WallH, 4.15f), WallMint);
            // wardrobe front
            Wall(h, new Vector3(8f + WallT / 4, WallH / 2, 4f + WallT / 2), new Vector3(4.15f, WallH, WallT), WallMint);

            // shared wall living | bedroom (x = 0), doorway z 1.7..2.7
            Wall(h, new Vector3(-WallT / 2, WallH / 2, 0.8125f), new Vector3(WallT, WallH, 1.775f), WallPeach);
            Wall(h, new Vector3(-WallT / 2, WallH / 2, 3.8875f), new Vector3(WallT, WallH, 2.375f), WallPeach);
            Wall(h, new Vector3(-WallT / 2, 2.05f, 2.2f), new Vector3(WallT, 0.7f, 1.0f), WallPeach); // lintel
            DoorFrame(h, new Vector3(-WallT / 2, 0f, 2.2f), 0f);
            DoorPanel(h, new Vector3(-WallT / 2, 0.83f, 1.72f), 100f, new Color(0.78f, 0.66f, 0.52f));

            // shared wall living | wardrobe (x = 6), doorway z 1.7..2.7
            Wall(h, new Vector3(6f + WallT / 2, WallH / 2, 0.8125f), new Vector3(WallT, WallH, 1.775f), WallPeach);
            Wall(h, new Vector3(6f + WallT / 2, WallH / 2, 3.3875f), new Vector3(WallT, WallH, 1.375f), WallPeach);
            Wall(h, new Vector3(6f + WallT / 2, 2.05f, 2.2f), new Vector3(WallT, 0.7f, 1.0f), WallPeach); // lintel
            DoorFrame(h, new Vector3(6f + WallT / 2, 0f, 2.2f), 0f);
            DoorPanel(h, new Vector3(6f + WallT / 2, 0.83f, 2.68f), -100f, new Color(0.70f, 0.78f, 0.66f));
        }

        static void DoorFrame(Transform h, Vector3 center, float rotY)
        {
            var g = NewObj(h, "DoorFrame");
            g.transform.position = center;
            g.transform.eulerAngles = new Vector3(0, rotY, 0);
            Box(g.transform, "PostA", new Vector3(0, 0.85f, -0.5f), new Vector3(0.10f, 1.7f, 0.12f), White, false);
            Box(g.transform, "PostB", new Vector3(0, 0.85f, 0.5f), new Vector3(0.10f, 1.7f, 0.12f), White, false);
            Box(g.transform, "Top", new Vector3(0, 1.72f, 0), new Vector3(0.12f, 0.10f, 1.14f), White, false);
        }

        static void DoorPanel(Transform h, Vector3 hinge, float openDeg, Color color)
        {
            var g = NewObj(h, "DoorPanel");
            g.transform.position = hinge;
            g.transform.eulerAngles = new Vector3(0, openDeg, 0);
            Box(g.transform, "Panel", new Vector3(0, 0, 0.475f), new Vector3(0.04f, 1.66f, 0.95f), color, false);
        }

        // ---------------------------------------------------------------
        static void BuildLiving(Transform h, HouseBuild result)
        {
            // sofa along the back wall
            var sofa = NewObj(h, "Sofa");
            sofa.transform.position = new Vector3(2.2f, 0f, 0.55f);
            Box(sofa.transform, "Base", new Vector3(0, 0.2f, 0), new Vector3(1.9f, 0.4f, 0.85f), SofaPink, true);
            Box(sofa.transform, "Back", new Vector3(0, 0.62f, -0.33f), new Vector3(1.9f, 0.5f, 0.22f), SofaPink, true);
            Box(sofa.transform, "ArmL", new Vector3(-0.93f, 0.3f, 0), new Vector3(0.22f, 0.6f, 0.85f), SofaPink, true);
            Box(sofa.transform, "ArmR", new Vector3(0.93f, 0.3f, 0), new Vector3(0.22f, 0.6f, 0.85f), SofaPink, true);
            Box(sofa.transform, "CushionL", new Vector3(-0.45f, 0.46f, 0.05f), new Vector3(0.8f, 0.14f, 0.66f), SofaCream, false);
            Box(sofa.transform, "CushionR", new Vector3(0.45f, 0.46f, 0.05f), new Vector3(0.8f, 0.14f, 0.66f), SofaCream, false);

            // coffee table (the decoration spot sits on it)
            var table = NewObj(h, "CoffeeTable");
            table.transform.position = new Vector3(3f, 0f, 1.7f);
            Box(table.transform, "Top", new Vector3(0, 0.45f, 0), new Vector3(1.0f, 0.06f, 0.55f), WoodLight, true);
            Box(table.transform, "LegA", new Vector3(-0.44f, 0.21f, -0.21f), new Vector3(0.06f, 0.42f, 0.06f), Wood, false);
            Box(table.transform, "LegB", new Vector3(0.44f, 0.21f, -0.21f), new Vector3(0.06f, 0.42f, 0.06f), Wood, false);
            Box(table.transform, "LegC", new Vector3(-0.44f, 0.21f, 0.21f), new Vector3(0.06f, 0.42f, 0.06f), Wood, false);
            Box(table.transform, "LegD", new Vector3(0.44f, 0.21f, 0.21f), new Vector3(0.06f, 0.42f, 0.06f), Wood, false);

            // decoration spot (mission 3)
            var spot = NewObj(h, "DecorSpot");
            spot.transform.position = new Vector3(3f, 0.485f, 1.7f);
            var ring = Box(spot.transform, "Ring", Vector3.zero, new Vector3(0.34f, 0.012f, 0.34f), SpotYellow, false);
            ring.GetComponent<Renderer>().sharedMaterial = Viz.GetUnlit(SpotYellow);
            var placed = NewObj(spot.transform, "PlacedVase");
            placed.SetActive(false);
            Cyl(placed.transform, "Pot", new Vector3(0, 0.08f, 0), new Vector3(0.14f, 0.08f, 0.14f), VasePink, false);
            Sphere(placed.transform, "Plant", new Vector3(0, 0.19f, 0), new Vector3(0.16f, 0.16f, 0.16f), PlantGreen, false);
            spot.AddComponent<DecorPlacementSpot>();

            // window on the back wall (glass sits just in front of the wall's inner face)
            var window = NewObj(h, "Window");
            window.transform.position = new Vector3(4.6f, 1.4f, 0.03f);
            var glass = Box(window.transform, "Glass", Vector3.zero, new Vector3(1.1f, 0.9f, 0.03f), new Color(0.75f, 0.88f, 0.98f), false);
            glass.GetComponent<Renderer>().sharedMaterial = Viz.GetUnlit(new Color(0.75f, 0.88f, 0.98f));
            Box(window.transform, "FrameL", new Vector3(-0.58f, 0, 0), new Vector3(0.08f, 1.0f, 0.08f), White, false);
            Box(window.transform, "FrameR", new Vector3(0.58f, 0, 0), new Vector3(0.08f, 1.0f, 0.08f), White, false);
            Box(window.transform, "FrameT", new Vector3(0, 0.47f, 0), new Vector3(1.24f, 0.08f, 0.08f), White, false);
            Box(window.transform, "FrameB", new Vector3(0, -0.47f, 0), new Vector3(1.24f, 0.08f, 0.08f), White, false);

            // TV stand on the left inner wall
            var tv = NewObj(h, "TvStand");
            tv.transform.position = new Vector3(0.35f, 0f, 3.8f);
            Box(tv.transform, "Body", new Vector3(0, 0.2f, 0), new Vector3(0.9f, 0.4f, 0.4f), Wood, true);
            var screen = Box(tv.transform, "Screen", new Vector3(0, 0.72f, -0.05f), new Vector3(0.72f, 0.46f, 0.04f), new Color(0.25f, 0.27f, 0.32f), false);
            screen.GetComponent<Renderer>().sharedMaterial = Viz.GetUnlit(new Color(0.35f, 0.42f, 0.55f));

            // plant in the corner
            var plant = NewObj(h, "Plant");
            plant.transform.position = new Vector3(5.5f, 0f, 4.5f);
            Cyl(plant.transform, "Pot", new Vector3(0, 0.1f, 0), new Vector3(0.16f, 0.1f, 0.16f), PotTerra, true);
            Sphere(plant.transform, "Leaves", new Vector3(0, 0.42f, 0), new Vector3(0.34f, 0.34f, 0.34f), PlantGreen, false);
        }

        static void BuildBedroom(Transform h, HouseBuild result)
        {
            // bed along the back wall
            var bed = NewObj(h, "Bed");
            bed.transform.position = new Vector3(-2.2f, 0f, 0.85f);
            Box(bed.transform, "Frame", new Vector3(0, 0.15f, 0), new Vector3(1.4f, 0.3f, 2.1f), Wood, true);
            Box(bed.transform, "Mattress", new Vector3(0, 0.38f, 0), new Vector3(1.3f, 0.16f, 2.0f), White, true);
            Box(bed.transform, "Blanket", new Vector3(0, 0.47f, -0.35f), new Vector3(1.32f, 0.1f, 1.2f), BedLavender, false);
            Box(bed.transform, "Pillow", new Vector3(0, 0.5f, 0.75f), new Vector3(0.5f, 0.1f, 0.35f), SofaCream, false);
            Box(bed.transform, "Headboard", new Vector3(0, 0.55f, 1.05f), new Vector3(1.4f, 0.7f, 0.08f), Wood, true);

            // desk + chair on the left wall
            var desk = NewObj(h, "Desk");
            desk.transform.position = new Vector3(-3.55f, 0f, 2.6f);
            desk.transform.eulerAngles = new Vector3(0, 90f, 0);
            Box(desk.transform, "Top", new Vector3(0, 0.72f, 0), new Vector3(1.1f, 0.05f, 0.5f), WoodLight, true);
            Box(desk.transform, "LegA", new Vector3(-0.5f, 0.36f, -0.2f), new Vector3(0.06f, 0.72f, 0.06f), Wood, false);
            Box(desk.transform, "LegB", new Vector3(0.5f, 0.36f, -0.2f), new Vector3(0.06f, 0.72f, 0.06f), Wood, false);
            Box(desk.transform, "LegC", new Vector3(-0.5f, 0.36f, 0.2f), new Vector3(0.06f, 0.72f, 0.06f), Wood, false);
            Box(desk.transform, "LegD", new Vector3(0.5f, 0.36f, 0.2f), new Vector3(0.06f, 0.72f, 0.06f), Wood, false);
            var chair = NewObj(h, "Chair");
            chair.transform.position = new Vector3(-3.0f, 0f, 2.6f);
            Box(chair.transform, "Seat", new Vector3(0, 0.42f, 0), new Vector3(0.4f, 0.06f, 0.4f), SofaPink, true);
            Box(chair.transform, "Back", new Vector3(0, 0.7f, -0.18f), new Vector3(0.4f, 0.5f, 0.05f), SofaPink, true);

            // wall shelf (right inner wall) with the decoration vase
            var shelf = NewObj(h, "Shelf");
            shelf.transform.position = new Vector3(-WallT / 2 - 0.06f, 0f, 3.4f);
            Box(shelf.transform, "BoardA", new Vector3(0, 1.2f, 0), new Vector3(0.22f, 0.04f, 1.0f), WoodLight, false);
            Box(shelf.transform, "BoardB", new Vector3(0, 1.55f, 0), new Vector3(0.22f, 0.04f, 1.0f), WoodLight, false);

            var vase = NewObj(h, "DecorVase");
            vase.transform.position = new Vector3(-WallT / 2 - 0.06f, 1.23f, 3.4f);
            var model = NewObj(vase.transform, "Model");
            Cyl(model.transform, "Pot", new Vector3(0, 0.08f, 0), new Vector3(0.13f, 0.08f, 0.13f), VasePink, false);
            Sphere(model.transform, "Plant", new Vector3(0, 0.18f, 0), new Vector3(0.15f, 0.15f, 0.15f), PlantGreen, false);
            vase.AddComponent<DecorItemPickup>();

            // corner lamp
            var lamp = NewObj(h, "Lamp");
            lamp.transform.position = new Vector3(-3.6f, 0f, 0.45f);
            Cyl(lamp.transform, "Base", new Vector3(0, 0.02f, 0), new Vector3(0.16f, 0.02f, 0.16f), Wood, false);
            Cyl(lamp.transform, "Pole", new Vector3(0, 0.5f, 0), new Vector3(0.03f, 0.5f, 0.03f), Wood, false);
            Cyl(lamp.transform, "Shade", new Vector3(0, 0.95f, 0), new Vector3(0.22f, 0.14f, 0.22f), SofaCream, false);
        }

        static void BuildWardrobeRoom(Transform h, HouseBuild result)
        {
            // the wardrobe (opens the wardrobe UI)
            var wardrobe = NewObj(h, "Wardrobe");
            wardrobe.transform.position = new Vector3(8f, 0f, 0.38f);
            Box(wardrobe.transform, "Body", new Vector3(0, 0.95f, 0), new Vector3(1.7f, 1.9f, 0.55f), WardrobeWood, true);
            Box(wardrobe.transform, "Seam", new Vector3(0, 0.95f, 0.276f), new Vector3(0.02f, 1.8f, 0.02f), new Color(0.45f, 0.35f, 0.27f), false);
            Sphere(wardrobe.transform, "HandleL", new Vector3(-0.09f, 0.95f, 0.29f), new Vector3(0.04f, 0.04f, 0.04f), White, false);
            Sphere(wardrobe.transform, "HandleR", new Vector3(0.09f, 0.95f, 0.29f), new Vector3(0.04f, 0.04f, 0.04f), White, false);
            wardrobe.AddComponent<WardrobeInteractable>();
            result.wardrobeInteract = wardrobe.transform;

            // mirror on the right wall
            var mirror = NewObj(h, "Mirror");
            mirror.transform.position = new Vector3(10f - 0.05f, 1.3f, 2.5f);
            Box(mirror.transform, "Glass", Vector3.zero, new Vector3(0.05f, 1.3f, 0.6f), Mirror, false);
            mirror.transform.Find("Glass").GetComponent<Renderer>().sharedMaterial = Viz.GetUnlit(Mirror);
            Box(mirror.transform, "Frame", new Vector3(-0.02f, 0, 0), new Vector3(0.04f, 1.42f, 0.72f), Wood, false);

            // stool
            Cyl(h, "Stool", new Vector3(7.2f, 0.21f, 2.3f), new Vector3(0.3f, 0.21f, 0.3f), SofaPink, true);

            // dresser
            var dresser = NewObj(h, "Dresser");
            dresser.transform.position = new Vector3(9.3f, 0f, 3.4f);
            dresser.transform.eulerAngles = new Vector3(0, -30f, 0);
            Box(dresser.transform, "Body", new Vector3(0, 0.35f, 0), new Vector3(1.0f, 0.7f, 0.45f), WoodLight, true);
            Box(dresser.transform, "DrawerA", new Vector3(0, 0.52f, 0.226f), new Vector3(0.9f, 0.2f, 0.01f), Wood, false);
            Box(dresser.transform, "DrawerB", new Vector3(0, 0.22f, 0.226f), new Vector3(0.9f, 0.2f, 0.01f), Wood, false);
        }

        static void BuildZones(Transform h)
        {
            AddZone(h, "Zone_Living", Rooms.Living, new Vector3(3f, 1.2f, 2.5f), new Vector3(5.8f, 2.4f, 4.8f));
            AddZone(h, "Zone_Bedroom", Rooms.Bedroom, new Vector3(-2f, 1.2f, 2f), new Vector3(3.8f, 2.4f, 3.8f));
            AddZone(h, "Zone_Wardrobe", Rooms.Wardrobe, new Vector3(8f, 1.2f, 2f), new Vector3(3.8f, 2.4f, 3.8f));
        }

        static void AddZone(Transform h, string name, string room, Vector3 center, Vector3 size)
        {
            var go = NewObj(h, name);
            go.transform.position = center;
            var z = go.AddComponent<RoomZone>();
            z.room = room;
            var col = go.AddComponent<BoxCollider>();
            col.center = Vector3.zero;
            col.size = size;
            col.isTrigger = true;
        }

        static void BuildLights(Transform h)
        {
            var lights = NewObj(h, "Lights");

            var sun = new GameObject("Sun");
            sun.transform.SetParent(lights.transform, false);
            sun.transform.rotation = Quaternion.Euler(38f, -30f, 0f);
            var dl = sun.AddComponent<Light>();
            dl.type = LightType.Directional;
            dl.color = new Color(1f, 0.96f, 0.9f);
            dl.intensity = 1.0f;
            dl.shadows = LightShadows.Soft;
            dl.shadowStrength = 0.35f;

            AddPoint(lights.transform, "Light_Living", new Vector3(3f, 2.1f, 2.5f), new Color(1f, 0.9f, 0.75f), 0.5f, 6f);
            AddPoint(lights.transform, "Light_Bedroom", new Vector3(-2f, 2.1f, 2f), new Color(0.8f, 0.85f, 1f), 0.4f, 5f);
            AddPoint(lights.transform, "Light_Wardrobe", new Vector3(8f, 2.1f, 2f), new Color(1f, 0.8f, 0.85f), 0.4f, 5f);
        }

        static void AddPoint(Transform parent, string name, Vector3 pos, Color color, float intensity, float range)
        {
            var go = new GameObject(name);
            go.transform.SetParent(parent, false);
            go.transform.position = pos;
            var l = go.AddComponent<Light>();
            l.type = LightType.Point;
            l.color = color;
            l.intensity = intensity;
            l.range = range;
            l.shadows = LightShadows.None;
        }

        // ---------------------------------------------------------------
        static void Wall(Transform h, Vector3 center, Vector3 size, Color color)
        {
            Box(h, "Wall", center, size, color, true);
        }

        static GameObject NewObj(Transform parent, string name)
        {
            GameObject go = new GameObject(name);
            go.transform.SetParent(parent, false);
            return go;
        }

        static GameObject Box(Transform parent, string name, Vector3 localPos, Vector3 size, Color color, bool collider)
        {
            GameObject go = GameObject.CreatePrimitive(PrimitiveType.Cube);
            go.name = name;
            go.transform.SetParent(parent, false);
            go.transform.localPosition = localPos;
            go.transform.localScale = size;
            Renderer r = go.GetComponent<Renderer>();
            r.sharedMaterial = Viz.Get(color);
            r.receiveShadows = true;
            if (!collider)
            {
                Collider c = go.GetComponent<Collider>();
                if (c != null) Object.Destroy(c);
            }
            return go;
        }

        static GameObject Cyl(Transform parent, string name, Vector3 localPos, Vector3 size, Color color, bool collider)
        {
            GameObject go = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            go.name = name;
            go.transform.SetParent(parent, false);
            go.transform.localPosition = localPos;
            go.transform.localScale = size;
            go.GetComponent<Renderer>().sharedMaterial = Viz.Get(color);
            if (!collider)
            {
                Collider c = go.GetComponent<Collider>();
                if (c != null) Object.Destroy(c);
            }
            return go;
        }

        static GameObject Sphere(Transform parent, string name, Vector3 localPos, Vector3 size, Color color, bool collider)
        {
            GameObject go = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            go.name = name;
            go.transform.SetParent(parent, false);
            go.transform.localPosition = localPos;
            go.transform.localScale = size;
            go.GetComponent<Renderer>().sharedMaterial = Viz.Get(color);
            if (!collider)
            {
                Collider c = go.GetComponent<Collider>();
                if (c != null) Object.Destroy(c);
            }
            return go;
        }
    }
}

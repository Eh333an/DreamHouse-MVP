using UnityEngine;

namespace DreamHouse
{
    /// <summary>
    /// The vase on the bedroom shelf (mission 3 step 1). Picking it up hides
    /// the model and shows a small held indicator above the player.
    /// </summary>
    public class DecorItemPickup : Interactable
    {
        Transform model;
        bool picked;

        void Start()
        {
            PromptText = "Take the vase";
            Transform m = transform.Find("Model");
            if (m != null) model = m;
            AddHighlightRing(new Color(0.7f, 0.9f, 0.95f));

            GameObject p = new GameObject("InteractPoint");
            p.transform.SetParent(transform, false);
            p.transform.localPosition = new Vector3(0f, 0.1f, 0.15f);
            InteractPoint = p.transform;
        }

        public override bool InteractableNow
        {
            get { return !picked; }
        }

        public override void OnInteract()
        {
            if (picked) return;
            picked = true;
            if (model != null) model.gameObject.SetActive(false);
            PromptText = "";

            DreamHouseGame game = DreamHouseGame.Instance;
            if (game != null) game.ShowHeldDecor(true);

            GameEvents.RaiseDecorPickedUp();
            if (game != null && game.Hud != null)
            {
                game.Hud.ShowToast("You are holding the vase. Find the glowing spot in the living room!");
            }
        }

        /// <summary>Restores the item (used on save-load when it was never picked).</summary>
        public void Restore()
        {
            picked = false;
            if (model != null) model.gameObject.SetActive(true);
            PromptText = "Take the vase";
        }

        /// <summary>Marks the item as picked without side effects (save-load).</summary>
        public void MarkPicked()
        {
            picked = true;
            if (model != null) model.gameObject.SetActive(false);
            PromptText = "";
        }
    }
}

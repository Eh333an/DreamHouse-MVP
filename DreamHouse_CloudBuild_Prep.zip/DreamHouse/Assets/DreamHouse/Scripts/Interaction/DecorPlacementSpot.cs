using UnityEngine;

namespace DreamHouse
{
    /// <summary>
    /// The glowing spot on the living room table (mission 3 step 2).
    /// Placing the vase here completes the decoration mission.
    /// </summary>
    public class DecorPlacementSpot : Interactable
    {
        Transform placedModel;
        Transform ring;
        bool placed;

        void Start()
        {
            PromptText = "Place the vase here";
            placedModel = transform.Find("PlacedVase");
            ring = transform.Find("Ring");

            GameObject p = new GameObject("InteractPoint");
            p.transform.SetParent(transform, false);
            p.transform.localPosition = new Vector3(0f, 0.1f, 0f);
            InteractPoint = p.transform;
        }

        void Update()
        {
            // gentle pulse while the spot is still empty
            if (ring != null && !placed)
            {
                float s = 1f + 0.08f * Mathf.Sin(Time.time * 3f);
                ring.localScale = new Vector3(0.34f * s, 0.012f, 0.34f * s);
            }
        }

        public override bool InteractableNow
        {
            get { return !placed; }
        }

        public override void OnInteract()
        {
            if (placed) return;
            DreamHouseGame game = DreamHouseGame.Instance;
            if (game == null) return;

            if (!game.HoldingDecor)
            {
                if (game.Hud != null) game.Hud.ShowToast("You need the vase first — it is on the bedroom shelf!");
                return;
            }

            placed = true;
            PromptText = "";
            if (placedModel != null) placedModel.gameObject.SetActive(true);
            if (ring != null)
            {
                Renderer r = ring.GetComponent<Renderer>();
                if (r != null) r.enabled = false;
            }
            game.ShowHeldDecor(false);
            SaveSystem.SetBool(SaveSystem.KeyDecorPlaced, true);
            GameEvents.RaiseDecorPlaced();
        }

        /// <summary>Restores placed state from save data.</summary>
        public void RestorePlaced()
        {
            placed = true;
            PromptText = "";
            if (placedModel != null) placedModel.gameObject.SetActive(true);
            if (ring != null)
            {
                Renderer r = ring.GetComponent<Renderer>();
                if (r != null) r.enabled = false;
            }
        }
    }
}

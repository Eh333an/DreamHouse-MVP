using UnityEngine;

namespace DreamHouse
{
    /// <summary>The wardrobe in the wardrobe room — opens the wardrobe UI.</summary>
    public class WardrobeInteractable : Interactable
    {
        void Start()
        {
            PromptText = "Open wardrobe";
            AddHighlightRing(new Color(0.98f, 0.8f, 0.5f));

            // interact point: chest height in front of the wardrobe
            GameObject p = new GameObject("InteractPoint");
            p.transform.SetParent(transform, false);
            p.transform.localPosition = new Vector3(0f, 1.0f, 0.45f);
            InteractPoint = p.transform;
        }

        public override void OnInteract()
        {
            DreamHouseGame game = DreamHouseGame.Instance;
            if (game != null && game.WardrobeUi != null)
            {
                game.WardrobeUi.ToggleOpen();
            }
        }
    }
}

using System.Collections.Generic;
using UnityEngine;

namespace DreamHouse
{
    /// <summary>
    /// Finds the nearest interactable in range + forward cone each frame,
    /// shows the prompt / floor ring, and fires E / Space / on-screen button.
    /// Disabled while the player is paused (wardrobe UI open).
    /// </summary>
    public class InteractionManager : MonoBehaviour
    {
        public const float Range = 1.35f;

        Interactable current;
        PlayerBody player;
        DreamHouseGame game;
        GameHudUi hud;

        void Start()
        {
            game = DreamHouseGame.Instance;
            if (game != null && game.PlayerRoot != null)
            {
                player = game.PlayerRoot.GetComponent<PlayerBody>();
            }
            hud = game != null ? game.Hud : null;
        }

        void Update()
        {
            if (game == null || player == null || hud == null) return;

            if (player.IsPaused)
            {
                if (current != null)
                {
                    current.SetHighlighted(false);
                    current = null;
                }
                hud.SetPrompt("");
                return;
            }

            FindNearest();
            hud.SetPrompt(current != null ? current.PromptText : "");

            bool pressed = Input.GetKeyDown(KeyCode.E) || Input.GetKeyDown(KeyCode.Space);
            if (pressed && current != null)
            {
                current.OnInteract();
            }
        }

        /// <summary>Called by the on-screen Interact button (mobile).</summary>
        public void TryInteract()
        {
            if (current != null && player != null && !player.IsPaused)
            {
                current.OnInteract();
            }
        }

        void FindNearest()
        {
            Interactable best = null;
            float bestD = Range;
            Vector3 pp = player.transform.position;
            Vector3 fwd = player.transform.forward;

            List<Interactable> list = game.Interactables;
            for (int i = 0; i < list.Count; i++)
            {
                Interactable cand = list[i];
                if (cand == null || !cand.InteractableNow) continue;

                Transform pt = cand.InteractPoint != null ? cand.InteractPoint : cand.transform;
                Vector3 ip = pt.position;
                float d = Vector3.Distance(pp, ip);
                if (d > Range) continue;

                // require a forward-facing match, except when very close
                if (d > 0.9f)
                {
                    Vector3 to = ip - pp;
                    if (to.sqrMagnitude < 0.0001f) continue;
                    if (Vector3.Dot(to.normalized, fwd) < -0.2f) continue;
                }

                if (d < bestD)
                {
                    bestD = d;
                    best = cand;
                }
            }

            if (best != current)
            {
                if (current != null) current.SetHighlighted(false);
                current = best;
                if (current != null) current.SetHighlighted(true);
            }
        }
    }
}

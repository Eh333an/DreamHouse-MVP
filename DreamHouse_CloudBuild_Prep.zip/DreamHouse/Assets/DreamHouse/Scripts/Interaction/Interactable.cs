using UnityEngine;

namespace DreamHouse
{
    /// <summary>
    /// Base class for everything the player can interact with (wardrobe,
    /// decoration items, placement spots). Interaction is proximity + facing
    /// based, with a floor highlight ring and a HUD prompt.
    /// </summary>
    public abstract class Interactable : MonoBehaviour
    {
        [Tooltip("Short verb phrase shown in the HUD prompt, e.g. 'Open wardrobe'.")]
        public string PromptText = "";

        public Transform InteractPoint;

        Transform highlightRing;

        public virtual bool InteractableNow
        {
            get { return true; }
        }

        public virtual void OnInteract()
        {
        }

        public void AddHighlightRing(Color color)
        {
            GameObject go = GameObject.CreatePrimitive(PrimitiveType.Cube);
            go.name = "HighlightRing";
            go.transform.SetParent(transform, false);
            float worldY = 0.02f;
            go.transform.position = new Vector3(transform.position.x, worldY, transform.position.z);
            go.transform.localScale = new Vector3(0.5f, 0.015f, 0.5f);
            go.GetComponent<Renderer>().sharedMaterial = Viz.GetUnlit(color);
            Collider c = go.GetComponent<Collider>();
            if (c != null) Object.Destroy(c);
            go.SetActive(false);
            highlightRing = go.transform;
        }

        public void SetHighlighted(bool on)
        {
            if (highlightRing != null) highlightRing.gameObject.SetActive(on);
        }

        public virtual void Cleanup()
        {
            if (highlightRing != null)
            {
                Object.Destroy(highlightRing.gameObject);
                highlightRing = null;
            }
        }

        void OnEnable()
        {
            DreamHouseGame game = DreamHouseGame.Instance;
            if (game != null) game.RegisterInteractable(this);
        }

        void OnDisable()
        {
            DreamHouseGame game = DreamHouseGame.Instance;
            if (game != null) game.UnregisterInteractable(this);
        }
    }
}

using UnityEngine;

namespace DreamHouse
{
    /// <summary>
    /// Bridges keyboard (classic Input Manager axes) and the on-screen touch
    /// joystick into a single movement vector. Diagonals are clamped by the
    /// movement script so diagonal speed == straight-line speed.
    /// </summary>
    public static class VirtualInput
    {
        /// <summary>Written by TouchJoystick each frame; -1..1 on both axes.</summary>
        public static Vector2 Touch
        {
            get;
            set;
        }

        public static Vector2 ReadMove()
        {
            float x = Mathf.Clamp(Input.GetAxisRaw("Horizontal") + Touch.x, -1f, 1f);
            float y = Mathf.Clamp(Input.GetAxisRaw("Vertical") + Touch.y, -1f, 1f);
            return new Vector2(x, y);
        }

        public static void ClearTouch()
        {
            Touch = Vector2.zero;
        }
    }
}

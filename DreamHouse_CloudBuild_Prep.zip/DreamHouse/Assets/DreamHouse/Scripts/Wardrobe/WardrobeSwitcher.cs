using UnityEngine;

namespace DreamHouse
{
    /// <summary>
    /// Outfit switching system (spec section 10, extended for multi-part outfits).
    /// Outfits are pre-built GameObjects parented to the character's bone
    /// hierarchy, so switching is a pure visibility toggle: no teleport, no
    /// skeleton disturbance, no mesh pop-out while moving.
    /// The selected outfit of each character is saved separately.
    /// </summary>
    public class WardrobeSwitcher : MonoBehaviour
    {
        [System.Serializable]
        public class Entry
        {
            public string name;
            public GameObject[] parts;
        }

        [Tooltip("All outfits available to this character (managed by CharacterFactory).")]
        public Entry[] outfits;

        int currentIndex;
        bool isGirl;

        public int CurrentIndex
        {
            get { return currentIndex; }
        }

        public int Count
        {
            get { return outfits != null ? outfits.Length : 0; }
        }

        public string CurrentName
        {
            get { return (outfits != null && outfits.Length > 0) ? outfits[currentIndex].name : ""; }
        }

        /// <summary>Raised after a successful change (argument = new index).</summary>
        public event System.Action<int> OnOutfitChanged;

        public void Setup(bool isGirlCharacter)
        {
            isGirl = isGirlCharacter;
            if (outfits == null || outfits.Length == 0) return;

            int saved = SaveSystem.GetOutfitIndex(isGirl);
            currentIndex = (saved >= 0 && saved < outfits.Length) ? saved : 0;
            ShowOutfit(currentIndex);
        }

        public void NextOutfit()
        {
            if (outfits == null || outfits.Length == 0) return;
            ChangeTo((currentIndex + 1) % outfits.Length);
        }

        public void PreviousOutfit()
        {
            if (outfits == null || outfits.Length == 0) return;
            ChangeTo((currentIndex - 1 + outfits.Length) % outfits.Length);
        }

        /// <summary>
        /// Switch to an absolute outfit index. Returns false when nothing changed
        /// (same outfit / invalid index) so callers can avoid duplicate effects.
        /// </summary>
        public bool ChangeTo(int index)
        {
            if (outfits == null || outfits.Length == 0) return false;
            if (index < 0 || index >= outfits.Length) return false;
            if (index == currentIndex) return false;

            currentIndex = index;
            ShowOutfit(currentIndex);
            SaveSystem.SetOutfitIndex(isGirl, currentIndex);

            if (OnOutfitChanged != null) OnOutfitChanged(currentIndex);
            return true;
        }

        void ShowOutfit(int index)
        {
            if (outfits == null) return;
            for (int i = 0; i < outfits.Length; i++)
            {
                if (outfits[i] == null || outfits[i].parts == null) continue;
                for (int p = 0; p < outfits[i].parts.Length; p++)
                {
                    if (outfits[i].parts[p] != null)
                    {
                        outfits[i].parts[p].SetActive(i == index);
                    }
                }
            }
        }
    }
}

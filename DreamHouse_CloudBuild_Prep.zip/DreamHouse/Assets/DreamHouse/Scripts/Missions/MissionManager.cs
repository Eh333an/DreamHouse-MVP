using UnityEngine;

namespace DreamHouse
{
    /// <summary>
    /// The three MVP missions (spec section 6) with a per-mission completion
    /// flag, so a star can never be collected twice:
    ///   0 — open the wardrobe and try an outfit
    ///   1 — walk from the living room to the bedroom
    ///   2 — take the vase (bedroom shelf) and place it on the living spot
    /// </summary>
    public class MissionManager : MonoBehaviour
    {
        public class Mission
        {
            public int id;
            public string title;
            public string hint;
            public bool done;
        }

        public Mission[] missions;

        bool wardrobeUiOpen;

        public int Stars
        {
            get
            {
                int c = 0;
                for (int i = 0; i < missions.Length; i++) if (missions[i].done) c++;
                return c;
            }
        }

        void Start()
        {
            missions = new Mission[]
            {
                new Mission { id = 0, title = "Try a new outfit", hint = "Open the wardrobe in the wardrobe room" },
                new Mission { id = 1, title = "Visit the bedroom", hint = "Walk through the door on your left" },
                new Mission { id = 2, title = "Decorate the living room", hint = "Take the vase from the bedroom shelf, place it on the glowing spot" }
            };

            for (int i = 0; i < missions.Length; i++)
            {
                missions[i].done = SaveSystem.GetBool(SaveSystem.MissionKey(i), false);
            }

            GameEvents.RoomEntered += OnRoomEntered;
            GameEvents.OutfitChanged += OnOutfitChanged;
            GameEvents.WardrobeUiToggled += OnWardrobeUiToggled;
            GameEvents.DecorPlaced += OnDecorPlaced;

            DreamHouseGame game = DreamHouseGame.Instance;
            if (game != null)
            {
                game.Hud.RefreshMissions(missions);
                game.Hud.RefreshStars(Stars, missions.Length);
            }
        }

        void OnDestroy()
        {
            GameEvents.RoomEntered -= OnRoomEntered;
            GameEvents.OutfitChanged -= OnOutfitChanged;
            GameEvents.WardrobeUiToggled -= OnWardrobeUiToggled;
            GameEvents.DecorPlaced -= OnDecorPlaced;
        }

        void OnWardrobeUiToggled(bool open)
        {
            wardrobeUiOpen = open;
        }

        void OnOutfitChanged(int index)
        {
            if (wardrobeUiOpen) Complete(0);
        }

        void OnRoomEntered(string room)
        {
            if (room == Rooms.Bedroom) Complete(1);
        }

        void OnDecorPlaced()
        {
            Complete(2);
        }

        public void Complete(int id)
        {
            if (id < 0 || id >= missions.Length) return;
            Mission m = missions[id];
            if (m == null || m.done) return; // no duplicate rewards

            m.done = true;
            SaveSystem.SetBool(SaveSystem.MissionKey(id), true);

            DreamHouseGame game = DreamHouseGame.Instance;
            if (game != null && game.Hud != null)
            {
                game.Hud.RefreshMissions(missions);
                game.Hud.RefreshStars(Stars, missions.Length);
                game.Hud.ShowToast(
                    Stars >= missions.Length
                        ? "All missions complete! You decorated your dream house."
                        : "Mission complete: " + m.title + "  (+1 star)");
            }
        }
    }
}

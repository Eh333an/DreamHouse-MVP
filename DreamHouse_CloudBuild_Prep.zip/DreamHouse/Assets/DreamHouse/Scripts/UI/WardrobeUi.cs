using UnityEngine;
using UnityEngine.UI;

namespace DreamHouse
{
    /// <summary>
    /// Wardrobe panel: previous / next outfit buttons + done (spec section 5).
    /// While open, the player is paused (movement smoothly stops) and
    /// interactions are disabled.
    /// </summary>
    public class WardrobeUi : MonoBehaviour
    {
        static Color Ink = new Color(0.35f, 0.30f, 0.36f);
        static Color CardBg = new Color(0.99f, 0.97f, 0.95f, 0.97f);
        static Color Accent = new Color(0.72f, 0.55f, 0.80f);

        GameObject root;
        Text nameLabel;
        WardrobeSwitcher sw;
        bool open;

        public void Build(WardrobeSwitcher switcher)
        {
            sw = switcher;

            root = new GameObject("Root");
            root.transform.SetParent(transform, false);

            UiBuilder.Panel(root.transform, "Dim", new Color(0.2f, 0.17f, 0.24f, 0.35f),
                Vector2.zero, Vector2.one, Vector2.zero, Vector2.zero, false);

            RectTransform card = UiBuilder.Panel(root.transform, "Card", CardBg,
                new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(-280f, -180f), new Vector2(280f, 180f), false);

            UiBuilder.Label(card, "Title", "Wardrobe", 36, Ink, TextAnchor.MiddleCenter,
                new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(-160f, -64f), new Vector2(160f, -18f));

            nameLabel = UiBuilder.Label(card, "OutfitName", "", 26, Ink, TextAnchor.MiddleCenter,
                new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(-240f, -120f), new Vector2(240f, -78f));

            UiBuilder.Button(card, "PrevBtn", "< Prev", 26, new Color(0.88f, 0.85f, 0.90f), Ink,
                new Vector2(0f, 0f), new Vector2(0.5f, 0f), new Vector2(24f, 34f), new Vector2(-16f, 92f), OnPrev);
            UiBuilder.Button(card, "NextBtn", "Next >", 26, Accent, Color.white,
                new Vector2(0.5f, 0f), new Vector2(1f, 0f), new Vector2(16f, 34f), new Vector2(-24f, 92f), OnNext);

            UiBuilder.Button(card, "DoneBtn", "Done", 30, Accent, Color.white,
                new Vector2(0.5f, 0f), new Vector2(0.5f, 0f), new Vector2(-130f, -40f), new Vector2(130f, 22f), Close);

            UiBuilder.Label(card, "Hint", "Your outfit is saved. Movement pauses while the wardrobe is open.",
                16, new Color(0.55f, 0.5f, 0.56f), TextAnchor.MiddleCenter,
                new Vector2(0.5f, 0f), new Vector2(0.5f, 0f), new Vector2(-250f, 28f), new Vector2(250f, 52f));

            root.SetActive(false);
        }

        public void ToggleOpen()
        {
            if (open) Close();
            else Open();
        }

        public bool IsOpen
        {
            get { return open; }
        }

        void Open()
        {
            if (sw == null || open) return;
            open = true;
            Refresh();
            root.SetActive(true);

            PlayerBody body = GetBody();
            if (body != null) body.SetPaused(true);
            GameEvents.RaiseWardrobeUiToggled(true);
        }

        void Close()
        {
            if (!open) return;
            open = false;
            root.SetActive(false);

            PlayerBody body = GetBody();
            if (body != null) body.SetPaused(false);
            GameEvents.RaiseWardrobeUiToggled(false);
        }

        PlayerBody GetBody()
        {
            DreamHouseGame game = DreamHouseGame.Instance;
            if (game == null || game.PlayerRoot == null) return null;
            return game.PlayerRoot.GetComponent<PlayerBody>();
        }

        void OnPrev()
        {
            if (sw == null) return;
            sw.PreviousOutfit();
            Refresh();
        }

        void OnNext()
        {
            if (sw == null) return;
            sw.NextOutfit();
            Refresh();
        }

        void Refresh()
        {
            if (nameLabel == null || sw == null) return;
            nameLabel.text = sw.CurrentName + "   (" + (sw.CurrentIndex + 1) + " / " + sw.Count + ")";
        }
    }
}

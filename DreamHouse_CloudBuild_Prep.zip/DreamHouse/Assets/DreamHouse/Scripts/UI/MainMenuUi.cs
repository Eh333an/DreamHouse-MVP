using UnityEngine;
using UnityEngine.UI;

namespace DreamHouse
{
    /// <summary>
    /// Main menu: character selection (girl/boy), play, reset progress,
    /// control hints. Built entirely in code.
    /// </summary>
    public class MainMenuUi : MonoBehaviour
    {
        static Color BgCream = new Color(0.97f, 0.94f, 0.90f);
        static Color Ink = new Color(0.35f, 0.30f, 0.36f);
        static Color CardNormal = new Color(0.93f, 0.90f, 0.86f, 0.9f);
        static Color CardSelected = new Color(1f, 0.80f, 0.84f, 0.95f);
        static Color Accent = new Color(0.72f, 0.55f, 0.80f);
        static Color GirlHair = new Color(0.30f, 0.20f, 0.15f);
        static Color BoyHair = new Color(0.17f, 0.13f, 0.12f);
        static Color GirlSkin = new Color(0.88f, 0.70f, 0.57f);
        static Color BoySkin = new Color(0.85f, 0.65f, 0.51f);
        static Color Pink = new Color(0.93f, 0.55f, 0.58f);
        static Color Blue = new Color(0.30f, 0.57f, 0.86f);

        Image frameGirl;
        Image frameBoy;
        int selected = 0;

        public static void Build()
        {
            Canvas c = UiBuilder.CreateRootCanvas("MainMenu", 10);
            MainMenuUi menu = c.gameObject.AddComponent<MainMenuUi>();
            menu.BuildMenu();
        }

        void BuildMenu()
        {
            selected = SaveSystem.GetInt(SaveSystem.KeyCharacter, 0);
            Transform t = transform;

            UiBuilder.Panel(t, "Bg", BgCream, Vector2.zero, Vector2.one, Vector2.zero, Vector2.one, false);

            UiBuilder.Label(t, "Title", "Dream House", 72, Ink, TextAnchor.MiddleCenter,
                new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(-600f, -180f), new Vector2(600f, -70f));
            UiBuilder.Label(t, "Subtitle", "A cozy home & dress-up game — choose your character", 24,
                new Color(0.5f, 0.45f, 0.52f), TextAnchor.MiddleCenter,
                new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(-600f, -215f), new Vector2(600f, -185f));

            BuildCharacterCard(t, new Vector2(-330f, -160f), new Vector2(-30f, 160f), true, "Girl");
            BuildCharacterCard(t, new Vector2(30f, -160f), new Vector2(330f, 160f), false, "Boy");

            UiBuilder.Button(t, "PlayBtn", "Play", 42, Accent, Color.white,
                new Vector2(0.5f, 0.18f), new Vector2(0.5f, 0.18f), new Vector2(-140f, -55f), new Vector2(140f, 55f),
                OnPlay);

            UiBuilder.Button(t, "ResetBtn", "Reset progress", 20, new Color(0.85f, 0.82f, 0.86f), Ink,
                new Vector2(0.5f, 0.09f), new Vector2(0.5f, 0.09f), new Vector2(-110f, -28f), new Vector2(110f, 28f),
                OnReset);

            UiBuilder.Label(t, "Hint1", "PC: WASD / arrows to move  •  hold left mouse to orbit camera  •  E to interact",
                19, new Color(0.5f, 0.45f, 0.52f), TextAnchor.MiddleCenter,
                new Vector2(0.5f, 0.045f), new Vector2(0.5f, 0.045f), new Vector2(-640f, -34f), new Vector2(640f, -6f));
            UiBuilder.Label(t, "Hint2", "Mobile: left joystick to move  •  drag right side to orbit camera  •  USE button to interact",
                19, new Color(0.5f, 0.45f, 0.52f), TextAnchor.MiddleCenter,
                new Vector2(0.5f, 0f), new Vector2(0.5f, 0f), new Vector2(-640f, -40f), new Vector2(640f, -12f));

            ApplySelection();
        }

        void BuildCharacterCard(Transform t, Vector2 offsetMin, Vector2 offsetMax, bool isGirl, string name)
        {
            RectTransform card = UiBuilder.Panel(t, "Card_" + name, CardNormal,
                new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), offsetMin, offsetMax);
            var img = card.GetComponent<Image>();
            if (isGirl) frameGirl = img; else frameBoy = img;

            UnityEngine.Events.UnityAction sel;
            if (isGirl) sel = () => Select(0);
            else sel = () => Select(1);
            UiBuilder.Button(card, "SelectBtn", "", 1, new Color(1f, 1f, 1f, 0f), Color.white,
                Vector2.zero, Vector2.one, Vector2.zero, Vector2.one, sel);

            BuildIcon(card, isGirl);

            UiBuilder.Label(card, "Name", name, 30, Ink, TextAnchor.MiddleCenter,
                new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(-100f, -100f), new Vector2(100f, -56f));
            UiBuilder.Label(card, "Sub", "3 outfits", 18, new Color(0.55f, 0.5f, 0.56f), TextAnchor.MiddleCenter,
                new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f), new Vector2(-100f, -54f), new Vector2(100f, -28f));
        }

        void BuildIcon(Transform card, bool isGirl)
        {
            Color hair = isGirl ? GirlHair : BoyHair;
            Color skin = isGirl ? GirlSkin : BoySkin;

            // hair behind, face in front and slightly lower => "hair on top" look
            UiBuilder.Icon(card, "Hair", hair, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f),
                new Vector2(-72f, -140f), new Vector2(72f, 4f));
            UiBuilder.Icon(card, "Face", skin, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f),
                new Vector2(-64f, -156f), new Vector2(64f, -28f));
            if (isGirl)
            {
                // pink headband across the hair
                UiBuilder.Icon(card, "Headband", Pink, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f),
                    new Vector2(-66f, -40f), new Vector2(66f, -8f));
            }
            else
            {
                // blue tee hint at the bottom
                UiBuilder.Panel(card, "Tee", Blue, new Vector2(0.5f, 0.5f), new Vector2(0.5f, 0.5f),
                    new Vector2(-52f, -156f), new Vector2(52f, -108f), false);
            }
        }

        void Select(int id)
        {
            selected = id;
            SaveSystem.SetInt(SaveSystem.KeyCharacter, id);
            ApplySelection();
        }

        void ApplySelection()
        {
            if (frameGirl != null) frameGirl.color = selected == 0 ? CardSelected : CardNormal;
            if (frameBoy != null) frameBoy.color = selected == 1 ? CardSelected : CardNormal;
        }

        void OnPlay()
        {
            GameObject go = new GameObject("DreamHouseGame");
            DreamHouseGame game = go.AddComponent<DreamHouseGame>();
            Destroy(gameObject);
            game.StartGame(selected);
        }

        void OnReset()
        {
            SaveSystem.ResetAll();
            var label = transform.Find("ResetBtn/Label");
            if (label != null)
            {
                Text t = label.GetComponent<Text>();
                if (t != null) t.text = "Progress reset";
            }
        }
    }
}

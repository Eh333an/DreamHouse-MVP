using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

namespace DreamHouse
{
    /// <summary>
    /// Procedural uGUI factory (no prefab assets needed). All UI is built in
    /// code at runtime so the project stays asset-free for the MVP.
    /// </summary>
    public static class UiBuilder
    {
        static Font cachedFont;
        static EventSystem cachedEventSystem;

        public static Font Font()
        {
            if (cachedFont != null) return cachedFont;
            try { cachedFont = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf"); }
            catch (System.Exception) { cachedFont = null; }
            if (cachedFont == null)
            {
                try { cachedFont = Resources.GetBuiltinResource<Font>("Arial.ttf"); }
                catch (System.Exception e)
                {
                    Debug.LogError("[UiBuilder] no built-in font available: " + e.Message);
                    cachedFont = null;
                }
            }
            return cachedFont;
        }

        public static void EnsureEventSystem()
        {
            if (cachedEventSystem != null) return;
            if (EventSystem.current != null)
            {
                cachedEventSystem = EventSystem.current;
                return;
            }
            GameObject go = new GameObject("EventSystem");
            cachedEventSystem = go.AddComponent<EventSystem>();
            go.AddComponent<StandaloneInputModule>();
        }

        public static Canvas CreateRootCanvas(string name, int order)
        {
            EnsureEventSystem();
            GameObject go = new GameObject(name);
            Canvas c = go.AddComponent<Canvas>();
            c.renderMode = Canvas.RenderMode.ScreenSpaceOverlay;
            c.sortingOrder = order;
            CanvasScaler sc = go.AddComponent<CanvasScaler>();
            sc.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
            sc.referenceResolution = new Vector2(1280, 720);
            sc.matchWidthOrHeight = 0.5f;
            go.AddComponent<GraphicRaycaster>();
            return c;
        }

        public static RectTransform Panel(Transform parent, string name, Color bg,
            Vector2 anchorMin, Vector2 anchorMax, Vector2 offsetMin, Vector2 offsetMax, bool raycast = true)
        {
            GameObject go = new GameObject(name);
            go.transform.SetParent(parent, false);
            RectTransform rt = go.AddComponent<RectTransform>();
            rt.anchorMin = anchorMin;
            rt.anchorMax = anchorMax;
            rt.offsetMin = offsetMin;
            rt.offsetMax = offsetMax;
            Image img = go.AddComponent<Image>();
            img.color = bg;
            img.raycastTarget = raycast;
            return rt;
        }

        public static Image Icon(Transform parent, string name, Color color,
            Vector2 anchorMin, Vector2 anchorMax, Vector2 offsetMin, Vector2 offsetMax)
        {
            GameObject go = new GameObject(name);
            go.transform.SetParent(parent, false);
            RectTransform rt = go.AddComponent<RectTransform>();
            rt.anchorMin = anchorMin;
            rt.anchorMax = anchorMax;
            rt.offsetMin = offsetMin;
            rt.offsetMax = offsetMax;
            Image img = go.AddComponent<Image>();
            img.sprite = UiSprites.Circle();
            img.color = color;
            img.raycastTarget = false;
            return img;
        }

        public static Text Label(Transform parent, string name, string text, int size, Color color,
            TextAnchor align, Vector2 anchorMin, Vector2 anchorMax, Vector2 offsetMin, Vector2 offsetMax)
        {
            GameObject go = new GameObject(name);
            go.transform.SetParent(parent, false);
            RectTransform rt = go.AddComponent<RectTransform>();
            rt.anchorMin = anchorMin;
            rt.anchorMax = anchorMax;
            rt.offsetMin = offsetMin;
            rt.offsetMax = offsetMax;
            Text t = go.AddComponent<Text>();
            t.font = Font();
            t.text = text;
            t.fontSize = size;
            t.color = color;
            t.alignment = align;
            t.horizontalOverflow = HorizontalWrapMode.Overflow;
            t.verticalOverflow = VerticalWrapMode.Overflow;
            t.raycastTarget = false;
            return t;
        }

        public static Button Button(Transform parent, string name, string text, int size,
            Color bg, Color textColor, Vector2 anchorMin, Vector2 anchorMax,
            Vector2 offsetMin, Vector2 offsetMax, UnityAction onClick)
        {
            GameObject go = new GameObject(name);
            go.transform.SetParent(parent, false);
            RectTransform rt = go.AddComponent<RectTransform>();
            rt.anchorMin = anchorMin;
            rt.anchorMax = anchorMax;
            rt.offsetMin = offsetMin;
            rt.offsetMax = offsetMax;
            Image img = go.AddComponent<Image>();
            img.color = bg;
            Button b = go.AddComponent<Button>();
            b.targetGraphic = img;
            b.onClick.AddListener(onClick);

            GameObject lg = new GameObject("Label");
            lg.transform.SetParent(go.transform, false);
            RectTransform lrt = lg.AddComponent<RectTransform>();
            lrt.anchorMin = Vector2.zero;
            lrt.anchorMax = Vector2.one;
            lrt.offsetMin = Vector2.zero;
            lrt.offsetMax = Vector2.zero;
            Text t = lg.AddComponent<Text>();
            t.font = Font();
            t.text = text;
            t.fontSize = size;
            t.color = textColor;
            t.alignment = TextAnchor.MiddleCenter;
            t.horizontalOverflow = HorizontalWrapMode.Overflow;
            t.verticalOverflow = VerticalWrapMode.Overflow;
            t.raycastTarget = false;
            return b;
        }

        // ------------------------------------------------------------------
        public static GameHudUi CreateHud(DreamHouseGame game)
        {
            Canvas c = CreateRootCanvas("GameHud", 20);
            GameHudUi hud = c.gameObject.AddComponent<GameHudUi>();
            hud.Build(c.transform);
            return hud;
        }

        public static WardrobeUi CreateWardrobeUi(WardrobeSwitcher switcher)
        {
            Canvas c = CreateRootCanvas("WardrobeCanvas", 50);
            WardrobeUi w = c.gameObject.AddComponent<WardrobeUi>();
            w.Build(switcher);
            return w;
        }

        public static void CreateTouchJoystick()
        {
            Canvas c = CreateRootCanvas("TouchControls", 30);
            TouchJoystick j = c.gameObject.AddComponent<TouchJoystick>();
            j.Build(c.transform);
        }
    }
}

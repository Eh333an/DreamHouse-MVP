using UnityEngine;
using UnityEngine.UI;

namespace DreamHouse
{
    /// <summary>
    /// In-game HUD: star counter, mission list, interaction prompt,
    /// toasts, mobile interact button and keyboard hints.
    /// </summary>
    public class GameHudUi : MonoBehaviour
    {
        static Color Ink = new Color(0.35f, 0.30f, 0.36f);
        static Color PanelBg = new Color(1f, 1f, 1f, 0.72f);
        static Color DoneGreen = new Color(0.35f, 0.65f, 0.45f);

        Text starsLabel;
        Text[] missionLines;
        Text promptLabel;
        Text toastText;
        GameObject toastGo;
        float toastTimer;
        bool hasPrompt;

        public void Build(Transform canvas)
        {
            // stars — top left
            starsLabel = UiBuilder.Label(canvas, "Stars", "Stars: 0 / 3", 28, Ink, TextAnchor.UpperLeft,
                new Vector2(0f, 1f), new Vector2(0f, 1f), new Vector2(18f, -66f), new Vector2(360f, -16f));

            // mission panel — top right
            RectTransform panel = UiBuilder.Panel(canvas, "MissionPanel", PanelBg,
                new Vector2(1f, 1f), new Vector2(1f, 1f), new Vector2(-400f, -262f), new Vector2(-18f, -16f), false);
            UiBuilder.Label(panel, "Title", "Missions", 26, Ink, TextAnchor.UpperLeft,
                Vector2.zero, Vector2.one, new Vector2(14f, -44f), new Vector2(14f, -12f));
            missionLines = new Text[3];
            for (int i = 0; i < 3; i++)
            {
                missionLines[i] = UiBuilder.Label(panel, "Line" + i, "", 19, Ink, TextAnchor.UpperLeft,
                    new Vector2(0f, 1f), new Vector2(0f, 1f),
                    new Vector2(14f, -118f - i * 52f), new Vector2(-12f, -84f - i * 52f));
            }

            // interaction prompt — bottom center
            promptLabel = UiBuilder.Label(canvas, "Prompt", "", 30, Color.white, TextAnchor.MiddleCenter,
                new Vector2(0.5f, 0f), new Vector2(0.5f, 0f), new Vector2(-420f, 84f), new Vector2(420f, 140f));
            promptLabel.color = new Color(0.35f, 0.30f, 0.36f, 0.95f);

            // keyboard hint — bottom center (below prompt)
            if (!Input.touchSupported)
            {
                UiBuilder.Label(canvas, "KeyHint", "WASD move   •   hold mouse to look   •   E interact", 17,
                    new Color(0.5f, 0.45f, 0.52f), TextAnchor.MiddleCenter,
                    new Vector2(0.5f, 0f), new Vector2(0.5f, 0f), new Vector2(-420f, 40f), new Vector2(420f, 66f));
            }

            // toast — top center
            toastText = UiBuilder.Label(canvas, "Toast", "", 26, Ink, TextAnchor.MiddleCenter,
                new Vector2(0.5f, 1f), new Vector2(0.5f, 1f), new Vector2(-520f, -230f), new Vector2(520f, -170f));
            toastGo = toastText.gameObject;
            toastGo.SetActive(false);

            // mobile interact button — bottom right
            if (Input.touchSupported)
            {
                UiBuilder.Button(canvas, "InteractBtn", "USE", 30, new Color(0.72f, 0.55f, 0.80f), Color.white,
                    new Vector2(1f, 0f), new Vector2(1f, 0f), new Vector2(-170f, 230f), new Vector2(-30f, 370f),
                    OnInteractButton);
            }
        }

        void OnInteractButton()
        {
            DreamHouseGame game = DreamHouseGame.Instance;
            if (game == null) return;
            InteractionManager m = game.GetComponent<InteractionManager>();
            if (m != null) m.TryInteract();
        }

        public void RefreshStars(int stars, int total)
        {
            if (starsLabel == null) return;
            starsLabel.text = "Stars: " + stars + " / " + total;
        }

        public void RefreshMissions(MissionManager.Mission[] missions)
        {
            if (missionLines == null) return;
            for (int i = 0; i < missionLines.Length && i < missions.Length; i++)
            {
                MissionManager.Mission m = missions[i];
                missionLines[i].text = (m.done ? "[x] " : "[ ] ") + (m.id + 1) + ". " + m.title;
                missionLines[i].color = m.done ? DoneGreen : Ink;
            }
        }

        public void SetPrompt(string text)
        {
            if (promptLabel == null) return;
            bool has = !string.IsNullOrEmpty(text);
            if (has == hasPrompt)
            {
                if (has) promptLabel.text = text;
                return;
            }
            hasPrompt = has;
            promptLabel.text = has ? "[ E ]  " + text : "";
        }

        public void ShowToast(string msg)
        {
            if (toastText == null) return;
            toastText.text = msg;
            toastGo.SetActive(true);
            toastTimer = 2.4f;
        }

        void Update()
        {
            if (!toastGo.activeSelf) return;
            toastTimer -= Time.deltaTime;
            if (toastTimer <= 0f)
            {
                toastGo.SetActive(false);
                return;
            }
            Color c = toastText.color;
            c.a = Mathf.Clamp01(toastTimer / 0.5f);
            toastText.color = c;
        }
    }
}

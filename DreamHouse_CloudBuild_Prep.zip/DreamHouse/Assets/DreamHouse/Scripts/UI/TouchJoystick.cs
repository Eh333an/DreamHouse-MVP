using UnityEngine;
using UnityEngine.UI;

namespace DreamHouse
{
    /// <summary>
    /// Virtual joystick for touch devices (spec section 3.3). Lives on the
    /// left side of the screen; the right side is reserved for camera orbit.
    /// Writes to VirtualInput.Touch, which PlayerMovement reads.
    /// </summary>
    public class TouchJoystick : MonoBehaviour
    {
        const float Radius = 46f;

        RectTransform baseRect;
        RectTransform knobRect;
        int touchId = -1;

        public void Build(Transform canvas)
        {
            GameObject baseGo = new GameObject("JoystickBase");
            baseGo.transform.SetParent(canvas, false);
            baseRect = baseGo.AddComponent<RectTransform>();
            baseRect.anchorMin = Vector2.zero;
            baseRect.anchorMax = Vector2.zero;
            baseRect.anchoredPosition = new Vector2(120f, 120f);
            baseRect.sizeDelta = new Vector2(150f, 150f);
            Image bimg = baseGo.AddComponent<Image>();
            bimg.sprite = UiSprites.Circle();
            bimg.color = new Color(1f, 1f, 1f, 0.35f);

            GameObject knobGo = new GameObject("Knob");
            knobGo.transform.SetParent(baseRect, false);
            knobRect = knobGo.AddComponent<RectTransform>();
            knobRect.anchorMin = Vector2.zero;
            knobRect.anchorMax = Vector2.one;
            knobRect.sizeDelta = new Vector2(70f, 70f);
            knobRect.anchoredPosition = Vector2.zero;
            Image kimg = knobGo.AddComponent<Image>();
            kimg.sprite = UiSprites.Circle();
            kimg.color = new Color(1f, 0.72f, 0.76f, 0.85f);

            gameObject.SetActive(Input.touchSupported);
        }

        void Update()
        {
            if (!Input.touchSupported) return;

            // acquire a touch that started inside the base
            if (touchId == -1)
            {
                for (int i = 0; i < Input.touchCount; i++)
                {
                    Touch t = Input.GetTouch(i);
                    if (t.phase == TouchPhase.Began &&
                        RectTransformUtility.RectangleContainsScreenPoint(baseRect, t.position, null))
                    {
                        touchId = t.fingerId;
                        break;
                    }
                }
            }

            if (touchId != -1)
            {
                bool alive = false;
                Vector2 pos = Vector2.zero;
                for (int i = 0; i < Input.touchCount; i++)
                {
                    Touch t = Input.GetTouch(i);
                    if (t.fingerId == touchId)
                    {
                        alive = true;
                        pos = t.position;
                        if (t.phase == TouchPhase.Ended || t.phase == TouchPhase.Canceled)
                        {
                            touchId = -1;
                            alive = false;
                        }
                    }
                }

                if (alive)
                {
                    Vector2 local;
                    RectTransformUtility.ScreenPointToLocalPointInRectangle(baseRect, pos, null, out local);
                    if (local.magnitude > Radius) local = local.normalized * Radius;
                    knobRect.anchoredPosition = local;
                    VirtualInput.Touch = local / Radius;
                }
                else
                {
                    knobRect.anchoredPosition = Vector2.zero;
                    VirtualInput.ClearTouch();
                }
            }
            else
            {
                VirtualInput.ClearTouch();
            }
        }
    }
}

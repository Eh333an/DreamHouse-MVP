using UnityEngine;

namespace DreamHouse
{
    /// <summary>Runtime-generated sprites (soft circle) so the UI needs no art assets.</summary>
    public static class UiSprites
    {
        static Sprite circle;

        public static Sprite Circle()
        {
            if (circle != null) return circle;

            int s = 64;
            var tex = new Texture2D(s, s);
            var px = new Color32[s * s];
            float c = (s - 1) / 2f;

            for (int y = 0; y < s; y++)
            {
                for (int x = 0; x < s; x++)
                {
                    float dx = x - c;
                    float dy = y - c;
                    float d = Mathf.Sqrt(dx * dx + dy * dy) / c;
                    float a;
                    if (d <= 0.9f) a = 1f;
                    else if (d >= 1f) a = 0f;
                    else a = (1f - d) / 0.1f;
                    px[y * s + x] = new Color32(255, 255, 255, (byte)(a * 255f));
                }
            }

            tex.SetPixels32(px);
            tex.Apply();
            circle = Sprite.Create(tex, new Rect(0, 0, s, s), new Vector2(0.5f, 0.5f));
            return circle;
        }
    }
}

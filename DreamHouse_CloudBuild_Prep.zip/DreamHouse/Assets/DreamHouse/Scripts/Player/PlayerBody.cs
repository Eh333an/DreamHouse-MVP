using UnityEngine;

namespace DreamHouse
{
    /// <summary>
    /// Marker component on the player root. Also centralizes the "paused"
    /// state (wardrobe UI open) so movement is temporarily, smoothly stopped.
    /// </summary>
    public class PlayerBody : MonoBehaviour
    {
        public PlayerMovement Movement { get; private set; }

        public bool IsPaused { get; private set; }

        public void AttachMovement(PlayerMovement movement)
        {
            Movement = movement;
            if (IsPaused && movement != null) movement.MovementLocked = true;
        }

        public void SetPaused(bool paused)
        {
            if (IsPaused == paused) return;
            IsPaused = paused;
            if (Movement != null) Movement.MovementLocked = paused;
        }
    }
}

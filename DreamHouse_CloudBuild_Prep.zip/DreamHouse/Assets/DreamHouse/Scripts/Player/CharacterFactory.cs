using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace DreamHouse
{
    /// <summary>
    /// Builds the two kid characters procedurally from primitives at runtime.
    ///
    /// IMPORTANT — TEMPORARY (placeholder) assets, as declared in the project
    /// spec: the reference images are appearance guides only; there are no
    /// skinned FBX models in this MVP. The bone hierarchy below uses
    /// human-readable names (Hips, Spine, Chest, UpperArmL, ThighR, ...) so a
    /// real Humanoid-rigged FBX can be swapped in later with minimal rework.
    ///
    /// Appearance follows the sheets:
    ///   Girl — beige "OSS KEY" sweater (solid beige here, no printed text),
    ///   wide light-blue jeans, pink headband, wavy dark hair, barefoot.
    ///   Boy  — white tee with blue bottom print, denim shorts, white socks,
    ///   grey sneakers, short dark hair.
    /// </summary>
    public static class CharacterFactory
    {
        // ----- shared rig dimensions (local units, root at the floor) -----
        public const float HipsY = 0.55f;

        class OutfitSpec
        {
            public string name;
            public Color torsoTop;
            public Color torsoBottom;
            public Color legs;
            public float legLength;      // 1 = full length, < 0.9 = shorts
            public bool wideLegs;
            public Color feet;
            public bool shoes;
            public Color arms;           // full-sleeve color
            public bool shortSleeve;
            public Color sleeve;
            public int extra;            // 0 none, 1 dress, 2 hood
        }

        public class CharacterBuild
        {
            public GameObject root;
            public string[] outfitNames;
            public GameObject[][] outfitParts;
            public float headAnchorY;
            public float controllerHeight;
            public float controllerRadius;
        }

        public static CharacterBuild Create(bool isGirl, Vector3 position, float yawDegrees)
        {
            string name = isGirl ? "Girl" : "Boy";
            GameObject root = new GameObject(name);
            root.transform.position = position;
            root.transform.rotation = Quaternion.Euler(0f, yawDegrees, 0f);

            float vScale = isGirl ? 1f : 1.06f;
            GameObject visual = NewObj(root.transform, "VisualRoot");
            visual.transform.localScale = new Vector3(vScale, vScale, vScale);

            // ---------------- bone hierarchy (transform-only TEMP rig) ----------------
            Transform hips = NewBone(visual.transform, "Hips", new Vector3(0f, HipsY, 0f));
            Transform spine = NewBone(hips, "Spine", new Vector3(0f, 0.08f, 0f));
            Transform chest = NewBone(spine, "Chest", new Vector3(0f, 0.11f, 0f));
            Transform neck = NewBone(chest, "Neck", new Vector3(0f, 0.13f, 0f));
            Transform head = NewBone(neck, "Head", new Vector3(0f, 0.10f, 0f));

            Transform shoulderL = NewBone(chest, "ShoulderL", new Vector3(-0.155f, 0.09f, 0f));
            Transform shoulderR = NewBone(chest, "ShoulderR", new Vector3(0.155f, 0.09f, 0f));
            Transform upperArmL = NewBone(shoulderL, "UpperArmL", Vector3.zero);
            Transform upperArmR = NewBone(shoulderR, "UpperArmR", Vector3.zero);
            Transform lowerArmL = NewBone(upperArmL, "LowerArmL", new Vector3(0f, -0.15f, 0f));
            Transform lowerArmR = NewBone(upperArmR, "LowerArmR", new Vector3(0f, -0.15f, 0f));

            Transform thighL = NewBone(hips, "ThighL", new Vector3(-0.085f, -0.02f, 0f));
            Transform thighR = NewBone(hips, "ThighR", new Vector3(0.085f, -0.02f, 0f));
            Transform shinL = NewBone(thighL, "ShinL", new Vector3(0f, -0.27f, 0f));
            Transform shinR = NewBone(thighR, "ShinR", new Vector3(0f, -0.27f, 0f));
            Transform footL = NewBone(shinL, "FootL", new Vector3(0f, -0.22f, 0.05f));
            Transform footR = NewBone(shinR, "FootR", new Vector3(0f, -0.22f, 0.05f));

            Color skin = isGirl ? new Color(0.88f, 0.70f, 0.57f) : new Color(0.85f, 0.65f, 0.51f);
            Color hair = isGirl ? new Color(0.30f, 0.20f, 0.15f) : new Color(0.17f, 0.13f, 0.12f);

            // ---------------- permanent body parts ----------------
            Prim(chest, "Pelvis", PrimitiveType.Capsule, new Vector3(0f, -0.03f, 0f), new Vector3(0.26f, 0.09f, 0.20f), new Color(0.42f, 0.40f, 0.44f), false);
            BuildHead(head, isGirl, skin, hair);
            BuildArms(upperArmL, lowerArmL, upperArmR, lowerArmR, skin);

            // ---------------- outfits ----------------
            OutfitSpec[] specs = isGirl ? GirlOutfits(skin) : BoyOutfits(skin);
            var parts = new List<GameObject>[specs.Length];
            for (int i = 0; i < specs.Length; i++) parts[i] = new List<GameObject>();

            for (int i = 0; i < specs.Length; i++)
            {
                BuildOutfitParts(chest, upperArmL, upperArmR, lowerArmL, lowerArmR,
                    thighL, thighR, shinL, shinR, footL, footR, specs[i], skin, parts[i]);
            }

            // ---------------- collision ----------------
            float ccHeight = isGirl ? 1.08f : 1.14f;
            float ccRadius = isGirl ? 0.21f : 0.22f;
            CharacterController cc = root.AddComponent<CharacterController>();
            cc.height = ccHeight;
            cc.radius = ccRadius;
            cc.center = new Vector3(0f, ccHeight * 0.5f, 0f);
            cc.slopeLimit = 50f;
            cc.stepOffset = 0.15f;
            cc.skinWidth = 0.02f;

            return new CharacterBuild
            {
                root = root,
                outfitNames = System.Array.ConvertAll(specs, s => s.name),
                outfitParts = System.Array.ConvertAll(parts, l => l.ToArray()),
                headAnchorY = isGirl ? 1.0f : 1.06f,
                controllerHeight = ccHeight,
                controllerRadius = ccRadius
            };
        }

        // ------------------------------------------------------------------
        static OutfitSpec[] GirlOutfits(Color skin)
        {
            Color beige = new Color(0.79f, 0.72f, 0.57f);
            Color lightDenim = new Color(0.56f, 0.68f, 0.80f);
            Color pink = new Color(0.93f, 0.64f, 0.71f);
            Color green = new Color(0.56f, 0.72f, 0.58f);
            Color darkDenim = new Color(0.44f, 0.52f, 0.64f);
            return new OutfitSpec[]
            {
                new OutfitSpec {
                    name = "Beige Sweater + Jeans",
                    torsoTop = beige, torsoBottom = beige,
                    legs = lightDenim, legLength = 1f, wideLegs = true,
                    feet = skin, shoes = false,
                    arms = beige, shortSleeve = false, sleeve = beige, extra = 0
                },
                new OutfitSpec {
                    name = "Pink Dress",
                    torsoTop = pink, torsoBottom = pink,
                    legs = skin, legLength = 1f, wideLegs = false,
                    feet = skin, shoes = false,
                    arms = skin, shortSleeve = false, sleeve = skin, extra = 1
                },
                new OutfitSpec {
                    name = "Green Hoodie + Jeans",
                    torsoTop = green, torsoBottom = green,
                    legs = darkDenim, legLength = 1f, wideLegs = false,
                    feet = skin, shoes = false,
                    arms = green, shortSleeve = false, sleeve = green, extra = 2
                }
            };
        }

        static OutfitSpec[] BoyOutfits(Color skin)
        {
            Color white = new Color(0.96f, 0.96f, 0.94f);
            Color blue = new Color(0.30f, 0.57f, 0.86f);
            Color denim = new Color(0.60f, 0.69f, 0.79f);
            Color sneaker = new Color(0.55f, 0.57f, 0.60f);
            Color red = new Color(0.84f, 0.44f, 0.44f);
            Color jeans = new Color(0.46f, 0.56f, 0.70f);
            Color navy = new Color(0.31f, 0.37f, 0.53f);
            Color khaki = new Color(0.81f, 0.73f, 0.56f);
            return new OutfitSpec[]
            {
                new OutfitSpec {
                    name = "Print Tee + Shorts",
                    torsoTop = white, torsoBottom = blue,
                    legs = denim, legLength = 0.55f, wideLegs = false,
                    feet = sneaker, shoes = true,
                    arms = skin, shortSleeve = true, sleeve = white, extra = 0
                },
                new OutfitSpec {
                    name = "Red Top + Jeans",
                    torsoTop = red, torsoBottom = red,
                    legs = jeans, legLength = 1f, wideLegs = false,
                    feet = sneaker, shoes = true,
                    arms = red, shortSleeve = false, sleeve = red, extra = 0
                },
                new OutfitSpec {
                    name = "Navy Jacket + Khakis",
                    torsoTop = navy, torsoBottom = navy,
                    legs = khaki, legLength = 1f, wideLegs = false,
                    feet = sneaker, shoes = true,
                    arms = navy, shortSleeve = false, sleeve = navy, extra = 0
                }
            };
        }

        // ------------------------------------------------------------------
        static void BuildHead(Transform head, bool isGirl, Color skin, Color hair)
        {
            Prim(head, "Head", PrimitiveType.Sphere, Vector3.zero, new Vector3(0.22f, 0.24f, 0.23f), skin, false);
            if (isGirl)
            {
                // wavy bob: hair mass behind + top, face opening in front
                Prim(head, "Hair", PrimitiveType.Sphere, new Vector3(0f, 0.035f, -0.02f), new Vector3(0.24f, 0.25f, 0.25f), hair, false);
                Prim(head, "Face", PrimitiveType.Sphere, new Vector3(0f, -0.015f, 0.055f), new Vector3(0.19f, 0.17f, 0.16f), skin, false);
                Color pink = new Color(0.93f, 0.55f, 0.58f);
                Prim(head, "Headband", PrimitiveType.Sphere, new Vector3(0f, 0.075f, -0.005f), new Vector3(0.245f, 0.05f, 0.25f), pink, false);
            }
            else
            {
                // short crop
                Prim(head, "Hair", PrimitiveType.Sphere, new Vector3(0f, 0.045f, -0.035f), new Vector3(0.235f, 0.21f, 0.245f), hair, false);
                Prim(head, "Face", PrimitiveType.Sphere, new Vector3(0f, -0.02f, 0.055f), new Vector3(0.19f, 0.165f, 0.155f), skin, false);
            }
            Color eye = new Color(0.20f, 0.13f, 0.10f);
            Prim(head, "EyeL", PrimitiveType.Sphere, new Vector3(-0.048f, 0.005f, 0.105f), new Vector3(0.030f, 0.035f, 0.030f), eye, false);
            Prim(head, "EyeR", PrimitiveType.Sphere, new Vector3(0.048f, 0.005f, 0.105f), new Vector3(0.030f, 0.035f, 0.030f), eye, false);
        }

        static void BuildArms(Transform upperArmL, Transform lowerArmL, Transform upperArmR, Transform lowerArmR, Color skin)
        {
            // skin forearms + hands are permanent (sleeves are per-outfit)
            Prim(lowerArmL, "ForearmL", PrimitiveType.Capsule, new Vector3(0f, -0.065f, 0f), new Vector3(0.070f, 0.065f, 0.070f), skin, false);
            Prim(lowerArmR, "ForearmR", PrimitiveType.Capsule, new Vector3(0f, -0.065f, 0f), new Vector3(0.070f, 0.065f, 0.070f), skin, false);
            Prim(lowerArmL, "HandL", PrimitiveType.Sphere, new Vector3(0f, -0.14f, 0f), new Vector3(0.055f, 0.055f, 0.060f), skin, false);
            Prim(lowerArmR, "HandR", PrimitiveType.Sphere, new Vector3(0f, -0.14f, 0f), new Vector3(0.055f, 0.055f, 0.060f), skin, false);
        }

        static void BuildOutfitParts(
            Transform chest, Transform upperArmL, Transform upperArmR,
            Transform lowerArmL, Transform lowerArmR,
            Transform thighL, Transform thighR, Transform shinL, Transform shinR,
            Transform footL, Transform footR,
            OutfitSpec s, Color skin, List<GameObject> parts)
        {
            // torso (two capsules so the tee can be two-tone like the sheet)
            parts.Add(Prim(chest, "TorsoTop", PrimitiveType.Capsule, new Vector3(0f, 0.03f, 0f), new Vector3(0.30f, 0.14f, 0.24f), s.torsoTop, false));
            parts.Add(Prim(chest, "TorsoBottom", PrimitiveType.Capsule, new Vector3(0f, -0.10f, 0f), new Vector3(0.28f, 0.11f, 0.22f), s.torsoBottom, false));

            if (s.extra == 1) // dress skirt
            {
                parts.Add(Prim(chest, "Skirt", PrimitiveType.Cylinder, new Vector3(0f, -0.18f, 0f), new Vector3(0.44f, 0.13f, 0.36f), s.torsoBottom, false));
            }
            else if (s.extra == 2) // hood
            {
                parts.Add(Prim(chest, "Hood", PrimitiveType.Sphere, new Vector3(0f, 0.12f, -0.09f), new Vector3(0.16f, 0.12f, 0.12f), s.torsoTop, false));
            }

            // sleeves
            if (s.shortSleeve)
            {
                parts.Add(Prim(upperArmL, "SleeveL", PrimitiveType.Capsule, new Vector3(0f, -0.045f, 0f), new Vector3(0.095f, 0.065f, 0.095f), s.sleeve, false));
                parts.Add(Prim(upperArmR, "SleeveR", PrimitiveType.Capsule, new Vector3(0f, -0.045f, 0f), new Vector3(0.095f, 0.065f, 0.095f), s.sleeve, false));
            }
            else
            {
                parts.Add(Prim(upperArmL, "SleeveL", PrimitiveType.Capsule, new Vector3(0f, -0.075f, 0f), new Vector3(0.085f, 0.08f, 0.085f), s.arms, false));
                parts.Add(Prim(upperArmR, "SleeveR", PrimitiveType.Capsule, new Vector3(0f, -0.075f, 0f), new Vector3(0.085f, 0.08f, 0.085f), s.arms, false));
            }

            // legs
            if (s.legLength >= 0.9f)
            {
                float d = s.wideLegs ? 0.12f : 0.105f;
                parts.Add(Prim(thighL, "LegL", PrimitiveType.Capsule, new Vector3(0f, -0.135f, 0f), new Vector3(d, 0.14f, d), s.legs, false));
                parts.Add(Prim(thighR, "LegR", PrimitiveType.Capsule, new Vector3(0f, -0.135f, 0f), new Vector3(d, 0.14f, d), s.legs, false));
                parts.Add(Prim(shinL, "CalfL", PrimitiveType.Capsule, new Vector3(0f, -0.125f, 0f), new Vector3(0.095f, 0.13f, 0.095f), s.legs, false));
                parts.Add(Prim(shinR, "CalfR", PrimitiveType.Capsule, new Vector3(0f, -0.125f, 0f), new Vector3(0.095f, 0.13f, 0.095f), s.legs, false));
            }
            else
            {
                parts.Add(Prim(thighL, "ShortsL", PrimitiveType.Capsule, new Vector3(0f, -0.09f, 0f), new Vector3(0.125f, 0.09f, 0.125f), s.legs, false));
                parts.Add(Prim(thighR, "ShortsR", PrimitiveType.Capsule, new Vector3(0f, -0.09f, 0f), new Vector3(0.125f, 0.09f, 0.125f), s.legs, false));
                parts.Add(Prim(shinL, "CalfL", PrimitiveType.Capsule, new Vector3(0f, -0.12f, 0f), new Vector3(0.080f, 0.12f, 0.080f), skin, false));
                parts.Add(Prim(shinR, "CalfR", PrimitiveType.Capsule, new Vector3(0f, -0.12f, 0f), new Vector3(0.080f, 0.12f, 0.080f), skin, false));
                Color sock = new Color(0.94f, 0.94f, 0.92f);
                parts.Add(Prim(shinL, "SockL", PrimitiveType.Cylinder, new Vector3(0f, -0.06f, 0f), new Vector3(0.09f, 0.05f, 0.09f), sock, false));
                parts.Add(Prim(shinR, "SockR", PrimitiveType.Cylinder, new Vector3(0f, -0.06f, 0f), new Vector3(0.09f, 0.05f, 0.09f), sock, false));
            }

            // feet
            if (s.shoes)
            {
                parts.Add(Prim(footL, "ShoeL", PrimitiveType.Cube, new Vector3(0f, -0.015f, 0.03f), new Vector3(0.105f, 0.06f, 0.20f), s.feet, false));
                parts.Add(Prim(footR, "ShoeR", PrimitiveType.Cube, new Vector3(0f, -0.015f, 0.03f), new Vector3(0.105f, 0.06f, 0.20f), s.feet, false));
                Color sole = new Color(0.92f, 0.92f, 0.90f);
                parts.Add(Prim(footL, "SoleL", PrimitiveType.Cube, new Vector3(0f, -0.045f, 0.03f), new Vector3(0.110f, 0.02f, 0.21f), sole, false));
                parts.Add(Prim(footR, "SoleR", PrimitiveType.Cube, new Vector3(0f, -0.045f, 0.03f), new Vector3(0.110f, 0.02f, 0.21f), sole, false));
            }
            else
            {
                parts.Add(Prim(footL, "BareFootL", PrimitiveType.Capsule, new Vector3(0f, -0.01f, 0.02f), new Vector3(0.09f, 0.025f, 0.17f), skin, false));
                parts.Add(Prim(footR, "BareFootR", PrimitiveType.Capsule, new Vector3(0f, -0.01f, 0.02f), new Vector3(0.09f, 0.025f, 0.17f), skin, false));
            }
        }

        // ------------------------------------------------------------------
        static GameObject NewObj(Transform parent, string name)
        {
            GameObject go = new GameObject(name);
            go.transform.SetParent(parent, false);
            return go;
        }

        static Transform NewBone(Transform parent, string name, Vector3 localPosition)
        {
            GameObject go = NewObj(parent, name);
            go.transform.localPosition = localPosition;
            return go.transform;
        }

        /// <summary>
        /// Creates a primitive visual. Capsule/cylinder scale = (diameter, height/2, depth),
        /// sphere/cube scale = final size (Unity primitives are 1 unit, capsules/cylinders 2 units tall).
        /// </summary>
        static GameObject Prim(Transform parent, string name, PrimitiveType type, Vector3 localPos, Vector3 scale, Color color, bool addCollider)
        {
            GameObject go = GameObject.CreatePrimitive(type);
            go.name = name;
            go.transform.SetParent(parent, false);
            go.transform.localPosition = localPos;
            go.transform.localScale = scale;

            Renderer r = go.GetComponent<Renderer>();
            r.sharedMaterial = Viz.Get(color);
            r.shadowCastingMode = ShadowCastingMode.On;
            r.receiveShadows = false;

            if (!addCollider)
            {
                Collider c = go.GetComponent<Collider>();
                if (c != null) Object.Destroy(c);
            }
            return go;
        }
    }
}

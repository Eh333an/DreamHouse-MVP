using UnityEngine;

namespace DreamHouse
{
    /// <summary>
    /// Camera-relative third-person movement with acceleration/deceleration and
    /// speed-limited turning. This is the single source of truth for player
    /// translation (no Root Motion is used, per spec section 3.2).
    ///
    /// The real planar velocity drives the animation system, so foot cadence
    /// always matches actual ground speed (no foot sliding when speed changes).
    /// </summary>
    [RequireComponent(typeof(CharacterController))]
    public class PlayerMovement : MonoBehaviour
    {
        [Header("Movement (tunable from Inspector)")]
        [Tooltip("Max walk speed in m/s.")]
        public float moveSpeed = 2.2f;
        [Tooltip("How fast the body rotates toward the movement direction, degrees/second.")]
        public float rotationSpeed = 540f;
        [Tooltip("Speed-up rate in m/s^2.")]
        public float acceleration = 8f;
        [Tooltip("Slow-down rate in m/s^2 (higher = snappier stop).")]
        public float deceleration = 10f;

        [Header("References")]
        [Tooltip("Camera used to interpret input direction.")]
        public Transform cameraTransform;
        [Tooltip("Optional. Only used if a REAL Animator Controller with a Float parameter 'Speed' is assigned later (see README).")]
        public Animator animator;

        [SerializeField]
        CharacterController controller;

        Vector3 planarVelocity;
        bool movementLocked;

        public bool MovementLocked
        {
            get { return movementLocked; }
            set { movementLocked = value; }
        }

        /// <summary>Actual planar velocity (m/s) — used by animation + camera logic.</summary>
        public Vector3 CurrentVelocity
        {
            get { return planarVelocity; }
        }

        public Vector3 MoveDirection
        {
            get { return planarVelocity.sqrMagnitude > 0.0004f ? planarVelocity.normalized : Vector3.zero; }
        }

        /// <summary>0..1 — the same contract a real Blend Tree's "Speed" parameter uses.</summary>
        public float NormalizedSpeed
        {
            get { return Mathf.Clamp01(planarVelocity.magnitude / Mathf.Max(moveSpeed, 0.01f)); }
        }

        public bool IsMoving
        {
            get { return planarVelocity.sqrMagnitude > 0.0004f; }
        }

        void Awake()
        {
            if (controller == null) controller = GetComponent<CharacterController>();
        }

        void Update()
        {
            Vector2 input = VirtualInput.ReadMove();
            if (movementLocked) input = Vector2.zero;

            Vector3 direction = InputToWorld(input);
            float targetSpeed = input.sqrMagnitude > 0.01f ? moveSpeed : 0f;
            Vector3 targetVelocity = direction * targetSpeed;

            // Accelerate / decelerate — smooth start and smooth stop.
            float rate = targetSpeed > planarVelocity.magnitude ? acceleration : deceleration;
            planarVelocity = Vector3.MoveTowards(planarVelocity, targetVelocity, rate * Time.deltaTime);

            if (planarVelocity.sqrMagnitude > 0.000001f)
            {
                controller.Move(planarVelocity * Time.deltaTime);
            }

            // Gradual turning — only while actually moving, so the character
            // never spins in place and never snaps to a new heading.
            if (planarVelocity.sqrMagnitude > 0.02f)
            {
                Quaternion targetRotation = Quaternion.LookRotation(planarVelocity.normalized, Vector3.up);
                transform.rotation = Quaternion.RotateTowards(transform.rotation, targetRotation, rotationSpeed * Time.deltaTime);
            }

            // Feed a real Animator Controller when one is assigned (spec section 8/9).
            if (animator != null)
            {
                animator.SetFloat("Speed", NormalizedSpeed, 0.12f, Time.deltaTime);
            }
        }

        Vector3 InputToWorld(Vector2 input)
        {
            if (input.sqrMagnitude < 0.0001f) return Vector3.zero;

            Vector3 forward = cameraTransform != null
                ? Vector3.ProjectOnPlane(cameraTransform.forward, Vector3.up).normalized
                : Vector3.forward;
            Vector3 right = cameraTransform != null
                ? Vector3.ProjectOnPlane(cameraTransform.right, Vector3.up).normalized
                : Vector3.right;

            return (forward * input.y + right * input.x).normalized;
        }
    }
}

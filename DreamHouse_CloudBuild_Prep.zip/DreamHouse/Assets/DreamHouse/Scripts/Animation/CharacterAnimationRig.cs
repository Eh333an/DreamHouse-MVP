using System.Collections.Generic;
using UnityEngine;

namespace DreamHouse
{
    /// <summary>
    /// TEMPORARY placeholder animation system.
    ///
    /// Why not a plain Animator + Blend Tree here? Unity cannot compile new
    /// AnimationClips for the Animator at runtime (documented engine
    /// limitation), and this MVP ships no binary animation assets. So the
    /// placeholder rig uses a legacy Animation component with procedurally
    /// generated Idle + Walk clips, crossfaded in code.
    ///
    /// The crossfade uses the SAME 0..1 "Speed" contract (real planar
    /// velocity / maxSpeed) that the final Animator Blend Tree will use — and
    /// the walk phase is advanced by actual distance travelled, so foot
    /// cadence stays locked to ground speed (spec section 3.2).
    ///
    /// When real humanoid FBX + .controller assets arrive: attach the Animator
    /// (with the "Speed" parameter) to the character root — PlayerMovement
    /// already feeds it, and this component yields automatically (it detects
    /// a controller on the Animator and stops driving bones itself).
    /// </summary>
    public class CharacterAnimationRig : MonoBehaviour
    {
        [Header("Tuning (Inspector)")]
        [Tooltip("Max speed (m/s) the walk cadence is designed for.")]
        public float maxSpeedRef = 2.2f;
        [Tooltip("World distance covered per full leg cycle (m). Drives foot/step sync.")]
        public float strideLength = 0.65f;
        [Tooltip("How quickly the idle/walk blend responds to speed changes.")]
        public float blendSmoothing = 8f;

        public bool UsingClips { get; private set; }
        public bool YieldingToAnimator { get; private set; }

        Animator animator;
        Animation animation;
        AnimationClip idleClip;
        AnimationClip walkClip;

        Transform hips, spine, chest, neck, head;
        Transform upperArmL, upperArmR, lowerArmL, lowerArmR;
        Transform thighL, thighR, shinL, shinR;

        float walkPhase;   // seconds into the walk cycle, driven by real distance
        float walkWeight;  // damped 0..1 blend weight

        public void Setup(PlayerMovement movement)
        {
            FindBones();
            Animator a = GetComponent<Animator>();
            if (a != null) animator = a;
            TryBuildClips();
        }

        void FindBones()
        {
            hips = FindBone("Hips");
            spine = FindBone("Spine");
            chest = FindBone("Chest");
            neck = FindBone("Neck");
            head = FindBone("Head");
            upperArmL = FindBone("UpperArmL");
            upperArmR = FindBone("UpperArmR");
            lowerArmL = FindBone("LowerArmL");
            lowerArmR = FindBone("LowerArmR");
            thighL = FindBone("ThighL");
            thighR = FindBone("ThighR");
            shinL = FindBone("ShinL");
            shinR = FindBone("ShinR");
        }

        Transform FindBone(string name)
        {
            if (hips == null) hips = transform.Find("VisualRoot/Hips");
            if (hips == null) return null;
            if (name == "Hips") return hips;
            return hips.Find(name);
        }

        void TryBuildClips()
        {
            try
            {
                if (thighL == null || thighR == null || upperArmL == null)
                {
                    throw new System.Exception("bone hierarchy not found");
                }
                idleClip = BuildIdleClip();
                walkClip = BuildWalkClip();

                animation = gameObject.AddComponent<Animation>();
                animation.AddClip(idleClip, "Idle");
                animation.AddClip(walkClip, "Walk");
                animation["Idle"].weight = 1f;
                animation["Idle"].Play();
                animation["Walk"].weight = 0f;
                animation["Walk"].Play();

                UsingClips = true;
            }
            catch (System.Exception e)
            {
                Debug.LogError("[CharacterAnimationRig] placeholder clip build failed, using static pose: " + e.Message);
                UsingClips = false;
                ApplyStaticPose();
            }
        }

        void LateUpdate()
        {
            // Yield to a REAL Animator Controller when one is present (final pipeline).
            if (animator != null && animator.runtimeAnimatorController != null)
            {
                if (!YieldingToAnimator)
                {
                    YieldingToAnimator = true;
                    Debug.Log("[CharacterAnimationRig] Real Animator Controller detected — placeholder rig yielding.");
                }
                return;
            }
            if (!UsingClips) return;

            float speed = 0f;
            var movement = GetComponent<PlayerMovement>();
            if (movement != null) speed = movement.CurrentVelocity.magnitude;

            // Damped blend — smooth start (Idle->Walk) and smooth stop (Walk->Idle).
            float targetWeight = Mathf.SmoothStep(0.03f, 0.25f, Mathf.Clamp01(speed / Mathf.Max(maxSpeedRef, 0.1f)));
            walkWeight = Mathf.Lerp(walkWeight, targetWeight, 1f - Mathf.Exp(-blendSmoothing * Time.deltaTime));

            // Advance the walk cycle by ACTUAL distance travelled (foot sync).
            walkPhase += Time.deltaTime * (speed / Mathf.Max(strideLength, 0.01f));

            AnimationState idleState = animation["Idle"];
            AnimationState walkState = animation["Walk"];
            idleState.weight = 1f - walkWeight;
            walkState.weight = walkWeight;
            walkState.time = walkPhase % Mathf.Max(walkClip.length, 0.001f);
        }

        // ---------------- clip construction ----------------

        static Quaternion Q(float x, float y, float z)
        {
            return Quaternion.Euler(x, y, z);
        }

        static void AddQuat(AnimationClip clip, string path, List<float> times, Quaternion[] quats)
        {
            var cx = new AnimationCurve(); var cy = new AnimationCurve();
            var cz = new AnimationCurve(); var cw = new AnimationCurve();
            var kx = new Keyframe[times.Count]; var ky = new Keyframe[times.Count];
            var kz = new Keyframe[times.Count]; var kw = new Keyframe[times.Count];
            for (int i = 0; i < times.Count; i++)
            {
                kx[i] = new Keyframe(times[i], quats[i].x);
                ky[i] = new Keyframe(times[i], quats[i].y);
                kz[i] = new Keyframe(times[i], quats[i].z);
                kw[i] = new Keyframe(times[i], quats[i].w);
            }
            cx.keys = kx; cy.keys = ky; cz.keys = kz; cw.keys = kw;
            cx.postWrapMode = WrapMode.Loop; cx.preWrapMode = WrapMode.Loop;
            cy.postWrapMode = WrapMode.Loop; cy.preWrapMode = WrapMode.Loop;
            cz.postWrapMode = WrapMode.Loop; cz.preWrapMode = WrapMode.Loop;
            cw.postWrapMode = WrapMode.Loop; cw.preWrapMode = WrapMode.Loop;
            clip.SetCurve(path, typeof(Transform), "localRotation.x", cx);
            clip.SetCurve(path, typeof(Transform), "localRotation.y", cy);
            clip.SetCurve(path, typeof(Transform), "localRotation.z", cz);
            clip.SetCurve(path, typeof(Transform), "localRotation.w", cw);
        }

        static void AddFloat(AnimationClip clip, string path, string property, List<float> times, float[] values)
        {
            var keys = new Keyframe[times.Count];
            for (int i = 0; i < times.Count; i++) keys[i] = new Keyframe(times[i], values[i]);
            var curve = new AnimationCurve(keys);
            curve.postWrapMode = WrapMode.Loop;
            curve.preWrapMode = WrapMode.Loop;
            clip.SetCurve(path, typeof(Transform), property, curve);
        }

        string BonePath(Transform t)
        {
            string s = t.name;
            Transform p = t.parent;
            while (p != null && p != transform)
            {
                s = p.name + "/" + s;
                p = p.parent;
            }
            return s;
        }

        AnimationClip BuildIdleClip()
        {
            var clip = new AnimationClip();
            clip.frameRate = 30f;

            var t = new List<float>();
            for (int i = 0; i <= 6; i++) t.Add(i * 0.6f); // 0..3.6s

            // breathing: gentle chest scale + micro-tilt
            AddFloat(clip, BonePath(chest), "localScale.y", t, new float[] { 1f, 1.018f, 1f, 1.018f, 1f, 1.018f, 1f });
            AddQuat(clip, BonePath(chest), t, new Quaternion[] { Q(0, 0, 0), Q(1.6f, 0, 0), Q(0, 0, 0), Q(1.6f, 0, 0), Q(0, 0, 0), Q(1.6f, 0, 0), Q(0, 0, 0) });
            // slow head settle
            AddQuat(clip, BonePath(head), t, new Quaternion[] { Q(0, 0, 0), Q(-1.2f, 0, 0), Q(0, 0, 0), Q(-1.2f, 0, 0), Q(0, 0, 0), Q(-1.2f, 0, 0), Q(0, 0, 0) });
            // weight shift
            AddQuat(clip, BonePath(hips), t, new Quaternion[] { Q(0, 0, 0), Q(0, 0, 1.4f), Q(0, 0, 0), Q(0, 0, -1.4f), Q(0, 0, 0), Q(0, 0, 1.4f), Q(0, 0, 0) });
            // tiny arm sway
            AddQuat(clip, BonePath(upperArmL), t, new Quaternion[] { Q(0, 0, 2f), Q(0, 0, 0.5f), Q(0, 0, 2f), Q(0, 0, 0.5f), Q(0, 0, 2f), Q(0, 0, 0.5f), Q(0, 0, 2f) });
            AddQuat(clip, BonePath(upperArmR), t, new Quaternion[] { Q(0, 0, -2f), Q(0, 0, -0.5f), Q(0, 0, -2f), Q(0, 0, -0.5f), Q(0, 0, -2f), Q(0, 0, -0.5f), Q(0, 0, -2f) });
            // slight elbow bend so the idle pose matches the walk start pose
            AddQuat(clip, BonePath(lowerArmL), t, new Quaternion[] { Q(-16f, 0, 0), Q(-15f, 0, 0), Q(-16f, 0, 0), Q(-15f, 0, 0), Q(-16f, 0, 0), Q(-15f, 0, 0), Q(-16f, 0, 0) });
            AddQuat(clip, BonePath(lowerArmR), t, new Quaternion[] { Q(-16f, 0, 0), Q(-15f, 0, 0), Q(-16f, 0, 0), Q(-15f, 0, 0), Q(-16f, 0, 0), Q(-15f, 0, 0), Q(-16f, 0, 0) });
            // constant hips height so blending back from walk settles exactly
            var idleY = new float[t.Count];
            for (int i = 0; i < t.Count; i++) idleY[i] = CharacterFactory.HipsY;
            AddFloat(clip, BonePath(hips), "localPosition.y", t, idleY);

            clip.legacy = true;
            clip.EnsureQuaternionContinuity();
            return clip;
        }

        AnimationClip BuildWalkClip()
        {
            var clip = new AnimationClip();
            clip.frameRate = 30f;

            float len = strideLength / Mathf.Max(maxSpeedRef, 0.1f); // seconds per cycle
            int n = 9;
            var times = new List<float>();
            for (int i = 0; i < n; i++) times.Add(i * len / (n - 1));

            const float A = 26f; // thigh swing amplitude (deg)
            var thighLQ = new List<Quaternion>(); var thighRQ = new List<Quaternion>();
            var shinLQ = new List<Quaternion>(); var shinRQ = new List<Quaternion>();
            var armLQ = new List<Quaternion>(); var armRQ = new List<Quaternion>();
            var foreLQ = new List<Quaternion>(); var foreRQ = new List<Quaternion>();
            var spineQ = new List<Quaternion>(); var chestQ = new List<Quaternion>();
            var headQ = new List<Quaternion>(); var hipsQ = new List<Quaternion>();
            var hipsY = new List<float>();

            for (int i = 0; i < n; i++)
            {
                float ph = i / (float)(n - 1); // 0..1
                float s = Mathf.Sin(ph * Mathf.PI * 2f);
                float c = Mathf.Cos(ph * Mathf.PI * 2f);

                thighLQ.Add(Q(A * s, 0, 0));
                thighRQ.Add(Q(-A * s, 0, 0));

                float bendL = 8f + 30f * Mathf.Max(0f, -s); // knee bends most while leg swings back
                float bendR = 8f + 30f * Mathf.Max(0f, s);
                shinLQ.Add(Q(-bendL, 0, 0));
                shinRQ.Add(Q(-bendR, 0, 0));

                armLQ.Add(Q(-0.75f * A * s, 0, 0));  // arms counter to same-side leg
                armRQ.Add(Q(0.75f * A * s, 0, 0));
                foreLQ.Add(Q(-(16f + 6f * s), 0, 0));
                foreRQ.Add(Q(-(16f - 6f * s), 0, 0));

                spineQ.Add(Q(3f + 2.5f * (0.5f + 0.5f * c), 0, 2.2f * s)); // forward lean + lateral sway
                chestQ.Add(Q(1.2f * c, 0, -1.2f * s));
                headQ.Add(Q(-1.5f * c, 0, 0));
                hipsQ.Add(Q(0, 0, 2.0f * s));
                hipsY.Add(0.012f * Mathf.Abs(Mathf.Sin(ph * Mathf.PI * 2f))); // 2 beats per cycle
            }

            AddQuat(clip, BonePath(thighL), times, thighLQ.ToArray());
            AddQuat(clip, BonePath(thighR), times, thighRQ.ToArray());
            AddQuat(clip, BonePath(shinL), times, shinLQ.ToArray());
            AddQuat(clip, BonePath(shinR), times, shinRQ.ToArray());
            AddQuat(clip, BonePath(upperArmL), times, armLQ.ToArray());
            AddQuat(clip, BonePath(upperArmR), times, armRQ.ToArray());
            AddQuat(clip, BonePath(lowerArmL), times, foreLQ.ToArray());
            AddQuat(clip, BonePath(lowerArmR), times, foreRQ.ToArray());
            AddQuat(clip, BonePath(spine), times, spineQ.ToArray());
            AddQuat(clip, BonePath(chest), times, chestQ.ToArray());
            AddQuat(clip, BonePath(head), times, headQ.ToArray());
            AddQuat(clip, BonePath(hips), times, hipsQ.ToArray());

            // hips bob (localPosition.y around the factory base height)
            var yVals = new float[times.Count];
            for (int i = 0; i < times.Count; i++) yVals[i] = CharacterFactory.HipsY + hipsY[i];
            AddFloat(clip, BonePath(hips), "localPosition.y", times, yVals);

            clip.legacy = true;
            clip.EnsureQuaternionContinuity();
            return clip;
        }

        // ---------------- static fallback (only if clip build fails) ----------------
        void ApplyStaticPose()
        {
            if (lowerArmL != null) lowerArmL.localRotation = Q(-14f, 0, 0);
            if (lowerArmR != null) lowerArmR.localRotation = Q(-14f, 0, 0);
            if (upperArmL != null) upperArmL.localRotation = Q(0, 0, 2f);
            if (upperArmR != null) upperArmR.localRotation = Q(0, 0, -2f);
        }
    }
}

using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

namespace DreamHouse
{
    /// <summary>
    /// Root of one game session: builds the house, the selected character,
    /// camera, lights, UI and managers, then wires everything together and
    /// restores saved progress.
    /// </summary>
    public class DreamHouseGame : MonoBehaviour
    {
        public static DreamHouseGame Instance { get; private set; }

        public GameObject HouseRoot;
        public GameObject PlayerRoot;
        public Camera GameCamera;
        public Transform CameraTarget;

        public int CharacterId; // 0 = girl, 1 = boy
        public bool IsGirl => CharacterId == 0;

        public WardrobeSwitcher Wardrobe;
        public SmoothThirdPersonCamera Cam;
        public GameHudUi Hud;
        public WardrobeUi WardrobeUi;

        public List<Interactable> Interactables = new List<Interactable>();

        public bool HoldingDecor { get; private set; }
        GameObject heldDecorVisual;

        Vector3 heldDecorBase = new Vector3(0f, 1.3f, 0f);

        public void StartGame(int characterId)
        {
            Instance = this;
            CharacterId = characterId;

            SetupCameraAndLights();
            BuildHouse();
            BuildPlayer();
            BuildUi();
            BuildManagers();
            RestoreProgress();

            GameEvents.RaiseRoomEntered(Rooms.Living); // spawn room
            if (Hud != null) Hud.ShowToast("Welcome to your Dream House! Check the missions on the right.");
        }

        // ------------------------------------------------------------------
        void SetupCameraAndLights()
        {
            // reuse the default scene camera as the player camera
            Camera main = Camera.main;
            if (main == null)
            {
                GameObject go = new GameObject("Main Camera");
                go.tag = "MainCamera";
                main = go.AddComponent<Camera>();
                go.AddComponent<AudioListener>();
            }
            main.name = "PlayerCamera";
            main.clearFlags = CameraClearFlags.SolidColor;
            main.backgroundColor = new Color(0.96f, 0.90f, 0.85f);
            main.fieldOfView = 55f;
            main.nearClipPlane = 0.1f;
            main.farClipPlane = 60f;
            GameCamera = main;

            // soft, pastel ambient + warm key (spec: soft lighting, no heavy FX)
            RenderSettings.ambientMode = AmbientMode.Flat;
            RenderSettings.ambientLight = new Color(0.72f, 0.68f, 0.78f);
        }

        void BuildHouse()
        {
            HouseRoot = new GameObject("HouseRoot");
            HouseRoot.transform.SetParent(transform, false);
            HouseBuilder.Build(HouseRoot.transform, this);
        }

        void BuildPlayer()
        {
            bool isGirl = IsGirl;
            CharacterFactory.CharacterBuild build = CharacterFactory.Create(
                isGirl,
                new Vector3(3f, 0.02f, 3.1f),
                180f);
            PlayerRoot = build.root;
            // layer 2 ("Ignore Raycast", exists in every project) keeps the
            // camera wall-avoidance raycast from hitting the player itself
            PlayerRoot.layer = 2;

            PlayerBody body = PlayerRoot.AddComponent<PlayerBody>();
            PlayerMovement move = PlayerRoot.AddComponent<PlayerMovement>();

            Cam = GameCamera.GetComponent<SmoothThirdPersonCamera>();
            if (Cam == null) Cam = GameCamera.gameObject.AddComponent<SmoothThirdPersonCamera>();
            Cam.player = PlayerRoot.transform;
            Cam.headAnchorY = build.headAnchorY;
            move.cameraTransform = GameCamera.transform;
            body.AttachMovement(move);

            Wardrobe = PlayerRoot.AddComponent<WardrobeSwitcher>();
            var entries = new WardrobeSwitcher.Entry[build.outfitNames.Length];
            for (int i = 0; i < entries.Length; i++)
            {
                entries[i] = new WardrobeSwitcher.Entry
                {
                    name = build.outfitNames[i],
                    parts = build.outfitParts[i]
                };
            }
            Wardrobe.outfits = entries;
            Wardrobe.Setup(isGirl);
            Wardrobe.OnOutfitChanged += index => GameEvents.RaiseOutfitChanged(index);

            CharacterAnimationRig rig = PlayerRoot.AddComponent<CharacterAnimationRig>();
            rig.maxSpeedRef = move.moveSpeed;
            rig.Setup(move);
        }

        void BuildUi()
        {
            Hud = UiBuilder.CreateHud(this);
            WardrobeUi = UiBuilder.CreateWardrobeUi(Wardrobe);
            if (Input.touchSupported)
            {
                UiBuilder.CreateTouchJoystick();
            }
        }

        void BuildManagers()
        {
            // added AFTER the HUD so their Start() can refresh it
            gameObject.AddComponent<MissionManager>();
            gameObject.AddComponent<InteractionManager>();
        }

        void RestoreProgress()
        {
            if (Wardrobe == null) return;
            // outfit index was already restored inside Wardrobe.Setup

            if (SaveSystem.GetBool(SaveSystem.KeyDecorPlaced, false))
            {
                var spot = HouseRoot != null ? HouseRoot.GetComponentInChildren<DecorPlacementSpot>(true) : null;
                if (spot != null) spot.RestorePlaced();
                var item = HouseRoot != null ? HouseRoot.GetComponentInChildren<DecorItemPickup>(true) : null;
                if (item != null) item.MarkPicked();
            }
        }

        // ------------------------------------------------------------------
        public void ShowHeldDecor(bool show)
        {
            HoldingDecor = show;
            if (show && heldDecorVisual == null)
            {
                GameObject go = new GameObject("HeldDecor");
                go.transform.SetParent(PlayerRoot.transform, false);
                go.transform.localPosition = heldDecorBase;
                var pot = GameObject.CreatePrimitive(PrimitiveType.Cylinder);
                pot.name = "Pot";
                pot.transform.SetParent(go.transform, false);
                pot.transform.localPosition = Vector3.zero;
                pot.transform.localScale = new Vector3(0.13f, 0.08f, 0.13f);
                pot.GetComponent<Renderer>().sharedMaterial = Viz.Get(new Color(0.90f, 0.62f, 0.68f));
                Collider pc = pot.GetComponent<Collider>();
                if (pc != null) Object.Destroy(pc);
                var plant = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                plant.name = "Plant";
                plant.transform.SetParent(go.transform, false);
                plant.transform.localPosition = new Vector3(0f, 0.1f, 0f);
                plant.transform.localScale = new Vector3(0.15f, 0.15f, 0.15f);
                plant.GetComponent<Renderer>().sharedMaterial = Viz.Get(new Color(0.55f, 0.75f, 0.55f));
                Collider pl = plant.GetComponent<Collider>();
                if (pl != null) Object.Destroy(pl);
                heldDecorVisual = go;
            }
            if (heldDecorVisual != null) heldDecorVisual.SetActive(show);
        }

        public void RegisterInteractable(Interactable i)
        {
            if (i != null && !Interactables.Contains(i)) Interactables.Add(i);
        }

        public void UnregisterInteractable(Interactable i)
        {
            Interactables.Remove(i);
        }

        void Update()
        {
            // gentle bob for the held decoration
            if (HoldingDecor && heldDecorVisual != null)
            {
                heldDecorVisual.transform.localPosition =
                    heldDecorBase + new Vector3(0f, Mathf.Sin(Time.time * 3f) * 0.03f, 0f);
            }
        }

        void OnDestroy()
        {
            if (Instance == this) Instance = null;
        }
    }
}

using UnityEngine;

namespace DreamHouse
{
    /// <summary>
    /// Entry point. Attach this to any empty GameObject in ANY scene and press
    /// Play: it ensures a camera exists and builds the main menu.
    ///
    /// (Optional) Editor menu "DreamHouse > Open Home Scene (auto-setup)"
    /// creates a ready-made Home scene with this component for you.
    /// </summary>
    public class DreamHouseBootstrap : MonoBehaviour
    {
        void Start()
        {
            Application.targetFrameRate = 60;

            if (Camera.main == null)
            {
                GameObject go = new GameObject("Main Camera");
                go.tag = "MainCamera";
                Camera cam = go.AddComponent<Camera>();
                cam.clearFlags = CameraClearFlags.SolidColor;
                cam.backgroundColor = new Color(0.96f, 0.90f, 0.85f);
                go.AddComponent<AudioListener>();
            }

            MainMenuUi.Build();
        }
    }
}

using System;

namespace DreamHouse
{
    /// <summary>
    /// Small, central event bus so game systems (movement, wardrobe, missions, UI)
    /// stay decoupled.
    /// </summary>
    public static class GameEvents
    {
        /// <summary>Raised when the player enters a room. room = Rooms.Living | Rooms.Bedroom | Rooms.Wardrobe.</summary>
        public static event Action<string> RoomEntered;

        /// <summary>Raised after a successful outfit change. Argument = new outfit index.</summary>
        public static event Action<int> OutfitChanged;

        /// <summary>Raised when the wardrobe UI is opened/closed. Argument = isOpen.</summary>
        public static event Action<bool> WardrobeUiToggled;

        /// <summary>Raised when the player picks up the decoration item.</summary>
        public static event Action DecorPickedUp;

        /// <summary>Raised when the decoration item is placed on its spot.</summary>
        public static event Action DecorPlaced;

        public static void RaiseRoomEntered(string room)
        {
            if (RoomEntered != null) RoomEntered(room);
        }

        public static void RaiseOutfitChanged(int index)
        {
            if (OutfitChanged != null) OutfitChanged(index);
        }

        public static void RaiseWardrobeUiToggled(bool open)
        {
            if (WardrobeUiToggled != null) WardrobeUiToggled(open);
        }

        public static void RaiseDecorPickedUp()
        {
            if (DecorPickedUp != null) DecorPickedUp();
        }

        public static void RaiseDecorPlaced()
        {
            if (DecorPlaced != null) DecorPlaced();
        }
    }
}

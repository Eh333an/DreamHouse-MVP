using UnityEngine;

namespace DreamHouse
{
    /// <summary>
    /// All persistence goes through this wrapper (MVP uses PlayerPrefs, as per spec).
    /// Each mission is stored separately so rewards can never be collected twice.
    /// </summary>
    public static class SaveSystem
    {
        public const string KeyCharacter = "DH_Character";
        public const string KeyOutfitGirl = "DH_Outfit_Girl";
        public const string KeyOutfitBoy = "DH_Outfit_Boy";
        public const string KeyMission0 = "DH_Mission_0";
        public const string KeyMission1 = "DH_Mission_1";
        public const string KeyMission2 = "DH_Mission_2";
        public const string KeyDecorPlaced = "DH_Decor_Placed";

        public static int GetInt(string key, int fallback)
        {
            return PlayerPrefs.GetInt(key, fallback);
        }

        public static void SetInt(string key, int value)
        {
            PlayerPrefs.SetInt(key, value);
            PlayerPrefs.Save();
        }

        public static bool GetBool(string key, bool fallback)
        {
            return PlayerPrefs.GetInt(key, fallback ? 1 : 0) == 1;
        }

        public static void SetBool(string key, bool value)
        {
            PlayerPrefs.SetInt(key, value ? 1 : 0);
            PlayerPrefs.Save();
        }

        public static int GetOutfitIndex(bool isGirl)
        {
            return GetInt(isGirl ? KeyOutfitGirl : KeyOutfitBoy, 0);
        }

        public static void SetOutfitIndex(bool isGirl, int index)
        {
            SetInt(isGirl ? KeyOutfitGirl : KeyOutfitBoy, index);
        }

        public static string MissionKey(int id)
        {
            switch (id)
            {
                case 0: return KeyMission0;
                case 1: return KeyMission1;
                default: return KeyMission2;
            }
        }

        public static void ResetAll()
        {
            PlayerPrefs.DeleteKey(KeyCharacter);
            PlayerPrefs.DeleteKey(KeyOutfitGirl);
            PlayerPrefs.DeleteKey(KeyOutfitBoy);
            PlayerPrefs.DeleteKey(KeyMission0);
            PlayerPrefs.DeleteKey(KeyMission1);
            PlayerPrefs.DeleteKey(KeyMission2);
            PlayerPrefs.DeleteKey(KeyDecorPlaced);
            PlayerPrefs.Save();
        }
    }
}

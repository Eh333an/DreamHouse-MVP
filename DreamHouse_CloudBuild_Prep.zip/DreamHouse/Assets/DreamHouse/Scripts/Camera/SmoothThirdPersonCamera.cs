using UnityEngine;
using UnityEngine.UI;

namespace DreamHouse
{
    /// <summary>
    /// Third-person follow camera: damped (frame-rate independent) position and
    /// rotation, mouse/touch orbit, and a wall raycast that pulls the camera in
    /// instead of clipping through walls (spec section 3.3).
    /// All feel parameters are exposed in the Inspector.
    /// </summary>
    public class SmoothThirdPersonCamera : MonoBehaviour
    {
        [Header("References")]
        public Transform player;
        [Tooltip("Height of the look target above the player's feet.")]
        public float headAnchorY = 1.0f;

        [Header("Follow (tunable from Inspector)")]
        public float distance = 2.7f;
        public float minDistance = 0.9f;
        public float maxPitch = 48f;
        public float minPitch = -8f;
        [Tooltip("Higher = snappier follow.")]
        public float positionSmoothing = 10f;
        [Tooltip("Higher = snappier rotation.")]
        public float rotationSmoothing = 12f;
        [Tooltip("Extra pull-in distance when a wall blocks the view.")]
        public float wallPullIn = 0.25f;

        [Header("Orbit sensitivity (tunable from Inspector)")]
        public float mouseSensitivity = 0.28f;
        public float touchSensitivity = 0.16f;

        float yaw;
        float pitch = 18f;
        Vector3 currentPos;
        bool initialized;

        Vector2 lastMousePos;
        int orbitTouchId = -1;
        Vector2 lastTouchPos;

        void LateUpdate()
        {
            if (player == null) return;

            CollectOrbitInput();

            Vector3 target = player.position + Vector3.up * headAnchorY;

            if (!initialized)
            {
                currentPos = target - Quaternion.Euler(pitch, yaw, 0f) * Vector3.forward * distance;
                currentPos.y = Mathf.Max(currentPos.y, 0.15f);
                transform.position = currentPos;
                transform.rotation = Quaternion.LookRotation(target - currentPos, Vector3.up);
                initialized = true;
                return;
            }

            Vector3 desired = target - Quaternion.Euler(pitch, yaw, 0f) * Vector3.forward * distance;

            // wall avoidance: raycast from the look target toward the desired
            // camera position and clamp in front of the first hit.
            // Triggers are ignored (room zones) and the player layer (2 =
            // "Ignore Raycast") is masked out so the character never blocks
            // its own camera.
            Vector3 dir = desired - target;
            float dist = dir.magnitude;
            if (dist > 0.001f)
            {
                RaycastHit hit;
                if (Physics.Raycast(target, dir / dist, out hit, dist + 0.05f, ~(1 << 2), QueryTriggerInteraction.None))
                {
                    if (hit.distance < dist)
                    {
                        desired = target + (dir / dist) * Mathf.Max(hit.distance - wallPullIn, minDistance * 0.6f);
                    }
                }
            }
            desired.y = Mathf.Max(desired.y, 0.15f);

            // frame-rate independent damping
            float dt = Time.deltaTime;
            float kPos = 1f - Mathf.Exp(-positionSmoothing * dt);
            float kRot = 1f - Mathf.Exp(-rotationSmoothing * dt);

            currentPos = Vector3.Lerp(currentPos, desired, kPos);
            transform.position = currentPos;
            transform.rotation = Quaternion.Slerp(
                transform.rotation,
                Quaternion.LookRotation(target - currentPos, Vector3.up),
                kRot);
        }

        void CollectOrbitInput()
        {
            // ---- mouse orbit (left button drag), disabled over UI ----
            Vector2 mp = new Vector2(Input.mousePosition.x, Input.mousePosition.y);
            if (Input.GetMouseButtonDown(0) && !PointerOverUi())
            {
                lastMousePos = mp;
            }
            if (Input.GetMouseButton(0) && !PointerOverUi())
            {
                Vector2 d = mp - lastMousePos;
                lastMousePos = mp;
                yaw += d.x * mouseSensitivity;
                pitch = Mathf.Clamp(pitch - d.y * mouseSensitivity, minPitch, maxPitch);
            }

            // ---- touch orbit: a touch that BEGAN on the right side of the
            // screen (left side belongs to the joystick) ----
            for (int i = 0; i < Input.touchCount; i++)
            {
                Touch t = Input.GetTouch(i);
                if (orbitTouchId == -1 && t.phase == TouchPhase.Began &&
                    t.position.x > Screen.width * 0.55f && !PointerOverUi())
                {
                    orbitTouchId = t.fingerId;
                    lastTouchPos = t.position;
                }
                if (t.fingerId == orbitTouchId)
                {
                    if (t.phase == TouchPhase.Moved)
                    {
                        yaw += (t.position.x - lastTouchPos.x) * touchSensitivity;
                        pitch = Mathf.Clamp(pitch - (t.position.y - lastTouchPos.y) * touchSensitivity, minPitch, maxPitch);
                        lastTouchPos = t.position;
                    }
                    if (t.phase == TouchPhase.Ended || t.phase == TouchPhase.Canceled)
                    {
                        orbitTouchId = -1;
                    }
                }
            }
        }

        static bool PointerOverUi()
        {
            if (EventSystem.current == null) return false;
            return EventSystem.current.IsPointerOverGameObject();
        }
    }
}

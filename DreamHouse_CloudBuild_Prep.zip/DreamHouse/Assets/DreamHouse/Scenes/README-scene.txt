This folder receives the Home.unity scene created by the editor menu:

    DreamHouse > Open Home Scene (auto-setup)

You do not need to create the scene manually.

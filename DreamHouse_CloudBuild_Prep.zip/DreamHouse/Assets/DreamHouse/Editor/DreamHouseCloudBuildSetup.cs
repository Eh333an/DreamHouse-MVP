#if UNITY_EDITOR
using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEditor.Build;
using UnityEditor.Build.Reporting;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace DreamHouse.EditorTools
{
    /// <summary>
    /// Cloud-build helper: prepares the generated Home scene, Android player settings,
    /// and Build Settings scene list when the Unity Editor opens and before a build.
    /// This script has not been validated by an actual Unity Editor run in this package.
    /// </summary>
    [InitializeOnLoad]
    public sealed class DreamHouseCloudBuildSetup : IPreprocessBuildWithReport
    {
        private const string ScenePath = "Assets/DreamHouse/Scenes/Home.unity";
        public int callbackOrder { get { return -1000; } }

        static DreamHouseCloudBuildSetup()
        {
            EditorApplication.delayCall += EnsureProjectSetup;
        }

        [MenuItem("DreamHouse/Prepare Cloud Build")]
        public static void PrepareNow()
        {
            EnsureProjectSetup();
            Debug.Log("[DreamHouse] Cloud-build preparation finished. Check Build Settings and Android settings before publishing.");
        }

        public void OnPreprocessBuild(BuildReport report)
        {
            EnsureProjectSetup();
            if (!File.Exists(ScenePath))
                throw new BuildFailedException("Dream House scene was not generated: " + ScenePath);
        }

        private static void EnsureProjectSetup()
        {
            if (EditorApplication.isCompiling || EditorApplication.isUpdating) return;
            EnsureFolder("Assets", "DreamHouse");
            EnsureFolder("Assets/DreamHouse", "Scenes");

            if (!File.Exists(ScenePath))
            {
                Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
                GameObject root = new GameObject("DreamHouseBootstrap");
                root.AddComponent<DreamHouse.DreamHouseBootstrap>();
                EditorSceneManager.SaveScene(scene, ScenePath);
                Debug.Log("[DreamHouse] Generated Home scene for automated build.");
            }

            EditorBuildSettings.scenes = new[] { new EditorBuildSettingsScene(ScenePath, true) };
            PlayerSettings.productName = "Dream House";
            PlayerSettings.applicationIdentifier = "com.example.dreamhouse";
            PlayerSettings.defaultInterfaceOrientation = UIOrientation.LandscapeLeft;
            PlayerSettings.SetScriptingBackend(BuildTargetGroup.Android, ScriptingImplementation.IL2CPP);
            PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;
            PlayerSettings.SetApiCompatibilityLevel(BuildTargetGroup.Android, ApiCompatibilityLevel.NET_Standard_2_1);
        }

        private static void EnsureFolder(string parent, string name)
        {
            string path = parent + "/" + name;
            if (!AssetDatabase.IsValidFolder(path)) AssetDatabase.CreateFolder(parent, name);
        }
    }
}
#endif

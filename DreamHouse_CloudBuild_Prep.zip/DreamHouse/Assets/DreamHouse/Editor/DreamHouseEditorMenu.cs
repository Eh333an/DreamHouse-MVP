using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

namespace DreamHouse.EditorTools
{
    /// <summary>
    /// Quality-of-life editor menus:
    ///  - one-click Home scene creation with the bootstrap object attached
    ///  - Android player settings pre-configuration for the MVP build
    /// </summary>
    public static class DreamHouseEditorMenu
    {
        const string ScenePath = "Assets/DreamHouse/Scenes/Home.unity";

        [MenuItem("DreamHouse/Open Home Scene (auto-setup)")]
        static void OpenHomeScene()
        {
            EnsureFolder("Assets", "DreamHouse");
            EnsureFolder("Assets/DreamHouse", "Scenes");

            if (!File.Exists(ScenePath))
            {
                Scene scene = EditorSceneManager.NewScene(NewSceneSetup.EmptyScene, NewSceneMode.Single);
                GameObject go = new GameObject("DreamHouseBootstrap");
                go.AddComponent<DreamHouse.DreamHouseBootstrap>();
                EditorSceneManager.SaveScene(scene, ScenePath);
                Debug.Log("[DreamHouse] Created " + ScenePath + " with a DreamHouseBootstrap object.");
            }

            EditorSceneManager.OpenScene(ScenePath);
            GameObject found = GameObject.Find("DreamHouseBootstrap");
            if (found != null) Selection.activeGameObject = found;
        }

        [MenuItem("DreamHouse/Configure for Android build")]
        static void ConfigureAndroid()
        {
            try { PlayerSettings.productName = "Dream House"; }
            catch (System.Exception e) { Debug.LogException(e); }
            try { PlayerSettings.applicationIdentifier = "com.example.dreamhouse"; }
            catch (System.Exception e) { Debug.LogException(e); }
            try { PlayerSettings.defaultInterfaceOrientation = ScreenOrientation.LandscapeLeft; }
            catch (System.Exception e) { Debug.LogException(e); }
            try { PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64; }
            catch (System.Exception e) { Debug.LogException(e); }

            EditorUtility.DisplayDialog(
                "Dream House",
                "Android player settings configured (landscape, ARM64).\n\n" +
                "Next: File > Build Settings > Switch Platform to Android > Build Player.",
                "OK");
        }

        static void EnsureFolder(string path, string folderName)
        {
            string full = Path.Combine(path, folderName).Replace('\\', '/');
            if (!AssetDatabase.IsValidFolder(full))
            {
                AssetDatabase.CreateFolder(path, folderName);
            }
        }
    }
}

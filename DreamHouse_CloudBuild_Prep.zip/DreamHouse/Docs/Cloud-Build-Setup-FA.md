# آماده‌سازی Dream House برای Build ابری (نسخه مقدماتی)

## چه چیزی در این بسته تغییر کرده؟
- فایل `Packages/manifest.json` برای پروژه Unity اضافه شده است.
- اسکریپت `Assets/DreamHouse/Editor/DreamHouseCloudBuildSetup.cs` اضافه شده تا هنگام بازشدن Unity تلاش کند صحنه Home را بسازد، آن را در Build Settings ثبت کند و تنظیمات پایه Android را اعمال کند.
- فایل `.gitignore` برای حذف فایل‌های موقت Unity اضافه شده است.

## محدودیت مهم
این بسته در محیط دارای Unity Editor باز یا Build نشده است. اسکریپت کمکی و ساختار پروژه باید در Build واقعی اعتبارسنجی شود؛ موفقیت APK تضمین‌شده نیست. کدهای فعلی و مدل‌ها/انیمیشن‌های placeholder همچنان همان وضعیت قبلی را دارند.

## مسیر ابری از گوشی
1. یک حساب Unity بسازید و وارد Unity Dashboard شوید.
2. یک repository خصوصی GitHub بسازید؛ چون پروژه شامل دارایی‌های بازی است، خصوصی‌بودن توصیه می‌شود.
3. فایل‌های داخل پوشه `DreamHouse` را در ریشه repository قرار دهید؛ به‌ویژه `Assets/`, `ProjectSettings/ProjectVersion.txt`, `Packages/manifest.json` و فایل `.gitignore`.
4. در Unity Dashboard به DevOps → Build Automation بروید و GitHub را به‌عنوان source control وصل کنید. دسترسی فقط خواندن برای repository لازم است؛ برای auto-build مجوزهای اضافه لازم می‌شود.
5. یک Build Configuration با این مقادیر بسازید:
   - Unity version: `2022.3.20f1`
   - Platform: Android
   - Project subfolder path: خالی، اگر `Assets` و `ProjectSettings` در ریشه repository هستند
   - Architecture: ARM64
   - خروجی: APK، نه AAB، برای نصب مستقیم روی گوشی
6. Build را اجرا کنید، گزارش خطا را بررسی کنید و فقط پس از موفقیت، APK را از خروجی Build دانلود کنید.

## نکته مهم درباره هزینه و دسترسی
Unity Build Automation به source control متصل نیاز دارد و ممکن است برای حساب یا استفاده شما نیازمند فعال‌سازی/اشتراک Unity DevOps باشد. پیش از آپلود، صفحه قیمت‌گذاری و شرایط حساب خود را بررسی کنید. من از اینجا نمی‌توانم وارد حساب Unity یا GitHub شما شوم و repository یا Build را به جای شما فعال کنم.

## امنیت
- هرگز رمز عبور یا Personal Access Token خود را در چت ارسال نکنید.
- فقط به repository مخصوص همین بازی دسترسی بدهید.
- APK حاصل از Build ناموفق یا گزارش‌نشده را نصب نکنید.

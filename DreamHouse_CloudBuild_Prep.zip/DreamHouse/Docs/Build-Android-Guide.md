# راهنمای ساخت فایل APK قابل‌نصب (از زیپ تا بازی روی گوشی)

**مهم:** این زیپ «پروژه Unity» است، نه APK. تبدیل به APK **فقط در Unity Editor روی ویندوز** امکان‌پذیر است (در لینوکس/مک هم می‌شود، اما مسیر رسمی و ساده آن ویندوز است).

## گام ۰ — سیستم‌نیاز

- ویندوز ۱۰/۱۱ (۶۴بیت)، ترجیحاً ۱۶ گیگ RAM و SSD
- فضا: حدود ۲۰–۲۵ گیگ برای Unity + ماژول اندروید

## گام ۱ — نصب Unity (یک‌بار، رایگان)

1. `unity.com` → ثبت‌نام → دانلود **Unity Hub**.
2. در Hub: **Installs → Add → 2022.3 LTS** → در پنجره ماژول‌ها تیک بزنید:
   - ✅ **Android Build Support** (OpenJDK و NDK را خودکار می‌آورد — ضروری)
   - (اختیاری) iOS / WebGL نه.
3. نصب (۲۰–۴۰ دقیقه).

## گام ۲ — ساخت پروژه و کپی کد

1. Hub → **New Project** → **3D (Built-in Render Pipeline)** → نام: `DreamHouse` → Create.
2. از زیپ تحویلی، محتوای پوشه `DreamHouse/Assets` را داخل `DreamHouse/Assets` پروژه کپی کنید (پوشه‌های `Scripts`, `Editor`, `Scenes` زیر `Assets/DreamHouse`).
   - نکته: پوشه `Editor` حتماً داخل `Assets` باشد تا منوی `DreamHouse` ظاهر شود.
3. صبر کنید کامپایل تمام شود (Console بدون خطای قرمز).

## گام ۳ — باز کردن صحنه + تست سریع

1. منوی Unity: **`DreamHouse → Open Home Scene (auto-setup)`** → صحنه Home ساخته و باز می‌شود.
2. **Play** بزنید: منوی انتخاب شخصیت → Play → چند دقیقه حرکت/کمد/مأموریت را تست کنید (همان چک‌لیست `MovementTestReport.md`).
3. Stop. (پیشرفت ذخیره‌شده با دکمه Reset در منو پاک می‌شود.)

## گام ۴ — تنظیم اندروید

1. منو: **`DreamHouse → Configure for Android build`**
   (نام محصول «Dream House»، آیدی `com.example.dreamhouse`، لنداسکیپ، ARM64)
2. **File → Build Settings** → دکمه **Switch Platform** → **Android** → OK.
   - اول‌بار ۵–۱۵ دقیقه طول می‌کشد (تبدیل اسیت‌ها).
   - اگر از مسیر SDK شکایت کرد: Edit → Project Settings → External Tools → Android SDK/NDK را بررسی کنید (نصب Unity آن‌ها را خودکار گذاشته).

## گام ۵ — بیلد APK

1. در همان **Build Settings**: مسیر خروجی را انتخاب کنید (مثلاً `C:\DreamHouse\Build\`).
2. نام فایل: `Dream House` (پسوند `.apk` خودکار).
3. ⚠️ تیک **Export Project** را **نزنید** (وگرنه فقط پروژه اندروید خارج می‌شود، نه APK).
4. **Build Player** → ۵–۱۰ دقیقه صبر.
5. فایل `Dream House.apk` در همان پوشه ساخته می‌شود (حدود ۵۰–۱۲۰ مگابایت).

> امضای بیلد: Unity خودکار یک keystoreِ debug می‌سازد؛ برای نصب شخصی روی گوشی کاملاً کافی است. برای انتشار در گوگل‌پلی بعداً یک release key لازم می‌شود (فصل بعدی پروژه).

## گام ۶ — نصب روی گوشی

1. APK را به گوشی بفرستید (کابل USB، یا تلگرام/ایمیل/کارت حافظه — هر روشی).
2. روی فایل APK در گوشی ضربه بزنید → Install.
   - اگر «نصب از منابع ناشناس» خواستید: اجازه بدهید (تنظیمات امن).
3. بازی **Dream House** روی گوشی اجرا می‌شود؛ کنترل لمسی: جوی‌استیک چپ، درگ راست برای دوربین، دکمه USE برای تعامل.

## اگر مشکلی پیش آمد

| مشکل | راه‌حل |
|---|---|
| منوی `DreamHouse` در Unity نیست | پوشه‌ی `Editor` داخل `Assets` کپی نشده؛ دوباره کپی کنید و صبر کنید |
| خطای «Android SDK not found» در Switch Platform | Edit → Project Settings → External Tools؛ مسیر SDK/NDK باید `AppData/Local/Unity/...` باشد؛ یا از Hub ماژول Android را دوباره تیک/نصب کنید |
| بیلد خطای Java می‌دهد | ماژول OpenJDK داخل Unity Hub نصب نیست؛ از Installs → ماژول‌های 2022.3 تیک OpenJDK |
| بازی روی گوشی کند است | بیلد را با API Level 24+ تست کنید؛ فریم‌ریت هدف ۶۰ است؛ در نسخه‌ی بعد نورپردازی ساده‌تر می‌شود |
| «app not installed» | نسخه اندروید گوشی زیر 4.4 (API 19) است، یا امضای بیلد قبلی متفاوت است (بازی قبلی را حذف کنید) |

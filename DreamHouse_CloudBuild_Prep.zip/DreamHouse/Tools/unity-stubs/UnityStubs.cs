// ============================================================================
// UNITY API STUBS — used ONLY to compile-check the game scripts outside the
// Unity editor (Tools/verify-compile.sh). These are intentionally minimal
// signatures mirroring the real UnityEngine API surface the project uses.
// This file is NEVER part of the shipped project.
// ============================================================================
using System;
using System.Collections;
using System.Collections.Generic;

namespace UnityEngine
{
    // ---------------- math ----------------
    public struct Vector2
    {
        public float x, y;
        public Vector2(float x, float y) { this.x = x; this.y = y; }
        public static Vector2 zero { get { return new Vector2(0, 0); } }
        public static Vector2 one { get { return new Vector2(1, 1); } }
        public float magnitude { get { return (float)Math.Sqrt(x * x + y * y); } }
        public float sqrMagnitude { get { return x * x + y * y; } }
        public Vector2 normalized { get { float m = magnitude; return m > 1e-6f ? new Vector2(x / m, y / m) : zero; } }
        public static Vector2 operator +(Vector2 a, Vector2 b) { return new Vector2(a.x + b.x, a.y + b.y); }
        public static Vector2 operator -(Vector2 a, Vector2 b) { return new Vector2(a.x - b.x, a.y - b.y); }
        public static Vector2 operator *(Vector2 a, float d) { return new Vector2(a.x * d, a.y * d); }
        public static Vector2 operator /(Vector2 a, float d) { return new Vector2(a.x / d, a.y / d); }
        public static float Distance(Vector2 a, Vector2 b) { return (a - b).magnitude; }
        public static Vector2 Lerp(Vector2 a, Vector2 b, float t) { return a + (b - a) * t; }
    }

    public struct Vector3
    {
        public float x, y, z;
        public Vector3(float x, float y, float z) { this.x = x; this.y = y; this.z = z; }
        public static Vector3 zero { get { return new Vector3(0, 0, 0); } }
        public static Vector3 one { get { return new Vector3(1, 1, 1); } }
        public static Vector3 up { get { return new Vector3(0, 1, 0); } }
        public static Vector3 down { get { return new Vector3(0, -1, 0); } }
        public static Vector3 forward { get { return new Vector3(0, 0, 1); } }
        public static Vector3 right { get { return new Vector3(1, 0, 0); } }
        public static Vector3 back { get { return new Vector3(0, 0, -1); } }
        public float magnitude { get { return (float)Math.Sqrt(x * x + y * y + z * z); } }
        public float sqrMagnitude { get { return x * x + y * y + z * z; } }
        public Vector3 normalized { get { float m = magnitude; return m > 1e-6f ? new Vector3(x / m, y / m, z / m) : zero; } }
        public static Vector3 operator +(Vector3 a, Vector3 b) { return new Vector3(a.x + b.x, a.y + b.y, a.z + b.z); }
        public static Vector3 operator -(Vector3 a, Vector3 b) { return new Vector3(a.x - b.x, a.y - b.y, a.z - b.z); }
        public static Vector3 operator *(Vector3 a, float d) { return new Vector3(a.x * d, a.y * d, a.z * d); }
        public static Vector3 operator *(float d, Vector3 a) { return a * d; }
        public static Vector3 operator /(Vector3 a, float d) { return new Vector3(a.x / d, a.y / d, a.z / d); }
        public static float Dot(Vector3 a, Vector3 b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
        public static Vector3 Cross(Vector3 a, Vector3 b) { return new Vector3(a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x); }
        public static float Distance(Vector3 a, Vector3 b) { return (a - b).magnitude; }
        public static Vector3 Lerp(Vector3 a, Vector3 b, float t) { return a + (b - a) * t; }
        public static Vector3 MoveTowards(Vector3 current, Vector3 target, float maxDelta)
        {
            Vector3 d = target - current;
            float m = d.magnitude;
            if (m <= maxDelta || m < 1e-6f) return target;
            return current + d / m * maxDelta;
        }
        public static Vector3 ProjectOnPlane(Vector3 vector, Vector3 planeNormal)
        {
            return vector - planeNormal * Dot(vector, planeNormal) / Dot(planeNormal, planeNormal);
        }
        public static Vector3 ClampMagnitude(Vector3 vector, float maxLength)
        {
            if (vector.sqrMagnitude > maxLength * maxLength) return vector.normalized * maxLength;
            return vector;
        }
    }

    public struct Quaternion
    {
        public float x, y, z, w;
        public Quaternion(float x, float y, float z, float w) { this.x = x; this.y = y; this.z = z; this.w = w; }
        public static Quaternion identity { get { return new Quaternion(0, 0, 0, 1); } }
        public float angle { get { return 0f; } }
        public Vector3 eulerAngles { get { return Vector3.zero; } set { } }
        public static Quaternion Euler(float x, float y, float z) { return identity; }
        public static Quaternion Euler(Vector3 v) { return identity; }
        public static Quaternion AngleAxis(float angle, Vector3 axis) { return identity; }
        public static Quaternion LookRotation(Vector3 forward) { return identity; }
        public static Quaternion LookRotation(Vector3 forward, Vector3 upwards) { return identity; }
        public static Quaternion Slerp(Quaternion a, Quaternion b, float t) { return identity; }
        public static Quaternion Lerp(Quaternion a, Quaternion b, float t) { return identity; }
        public static Quaternion RotateTowards(Quaternion from, Quaternion to, float maxDegrees) { return identity; }
        public static float Dot(Quaternion a, Quaternion b) { return 0f; }
        public static Quaternion operator *(Quaternion a, Quaternion b) { return identity; }
        public static Vector3 operator *(Quaternion q, Vector3 v) { return v; }
    }

    public struct Color
    {
        public float r, g, b, a;
        public Color(float r, float g, float b) { this.r = r; this.g = g; this.b = b; this.a = 1f; }
        public Color(float r, float g, float b, float a) { this.r = r; this.g = g; this.b = b; this.a = a; }
        public static Color white { get { return new Color(1, 1, 1, 1); } }
        public static Color black { get { return new Color(0, 0, 0, 1); } }
        public static Color red { get { return new Color(1, 0, 0, 1); } }
        public static Color green { get { return new Color(0, 1, 0, 1); } }
        public static Color blue { get { return new Color(0, 0, 1, 1); } }
        public static Color yellow { get { return new Color(1, 1, 0, 1); } }
        public static Color transparent { get { return new Color(0, 0, 0, 0); } }
        public static Color clear { get { return new Color(0, 0, 0, 0); } }
        public static Color Lerp(Color a, Color b, float t) { return a; }
        public int GetHashCode() { return r.GetHashCode() ^ g.GetHashCode() ^ b.GetHashCode() ^ a.GetHashCode(); }
        public override bool Equals(object obj) { return obj is Color && ((Color)obj).r == r && ((Color)obj).g == g && ((Color)obj).b == b && ((Color)obj).a == a; }
    }

    public struct Color32
    {
        public byte r, g, b, a;
        public Color32(byte r, byte g, byte b, byte a) { this.r = r; this.g = g; this.b = b; this.a = a; }
    }

    public static class Mathf
    {
        public const float PI = (float)Math.PI;
        public const float Deg2Rad = (float)(Math.PI / 180.0);
        public const float Rad2Deg = (float)(180.0 / Math.PI);
        public static float Abs(float f) { return Math.Abs(f); }
        public static int Abs(int f) { return Math.Abs(f); }
        public static float Min(float a, float b) { return Math.Min(a, b); }
        public static int Min(int a, int b) { return Math.Min(a, b); }
        public static float Max(float a, float b) { return Math.Max(a, b); }
        public static int Max(int a, int b) { return Math.Max(a, b); }
        public static float Sqrt(float f) { return (float)Math.Sqrt(f); }
        public static float Pow(float f, float p) { return (float)Math.Pow(f, p); }
        public static float Sin(float f) { return (float)Math.Sin(f); }
        public static float Cos(float f) { return (float)Math.Cos(f); }
        public static float Tan(float f) { return (float)Math.Tan(f); }
        public static float Exp(float f) { return (float)Math.Exp(f); }
        public static float Floor(float f) { return (float)Math.Floor(f); }
        public static int FloorToInt(float f) { return (int)Math.Floor(f); }
        public static int RoundToInt(float f) { return (int)Math.Round(f); }
        public static float Sign(float f) { return f >= 0f ? 1f : -1f; }
        public static float Clamp(float v, float min, float max) { return v < min ? min : (v > max ? max : v); }
        public static int Clamp(int v, int min, int max) { return v < min ? min : (v > max ? max : v); }
        public static float Clamp01(float v) { return Clamp(v, 0f, 1f); }
        public static float Lerp(float a, float b, float t) { return a + (b - a) * Clamp01(t); }
        public static float LerpUnclamped(float a, float b, float t) { return a + (b - a) * t; }
        public static float MoveTowards(float current, float target, float maxDelta)
        {
            if (Abs(target - current) <= maxDelta) return target;
            return current + Sign(target - current) * maxDelta;
        }
        public static float SmoothStep(float from, float to, float t)
        {
            t = Clamp01(t);
            t = -2f * t * t * t + 3f * t * t;
            return to * t + from * (1f - t);
        }
        public static float Repeat(float t, float length) { return t - Floor(t / length) * length; }
        public static float DeltaAngle(float current, float target) { return 0f; }
        public static bool Approximately(float a, float b) { return Abs(a - b) < 1e-5f; }
    }

    public struct Bounds
    {
        public Vector3 center;
        public Vector3 size;
    }

    public struct Keyframe
    {
        public float time, value;
        public Keyframe(float time, float value) { this.time = time; this.value = value; }
    }

    public enum WrapMode { Clamp = 0, Loop = 1, PingPong = 2 }

    public class AnimationCurve
    {
        public Keyframe[] keys { get; set; }
        public WrapMode preWrapMode { get; set; }
        public WrapMode postWrapMode { get; set; }
        public AnimationCurve() { keys = new Keyframe[0]; }
        public AnimationCurve(Keyframe[] keys) { this.keys = keys; }
        public static AnimationCurve Linear(float t0, float v0, float t1, float v1) { return new AnimationCurve(new[] { new Keyframe(t0, v0), new Keyframe(t1, v1) }); }
        public void AddKey(Keyframe k) { }
        public void AddKey(float time, float value) { }
        public float Evaluate(float time) { return 0f; }
    }

    // ---------------- core object model ----------------
    public class Object
    {
        public string name { get; set; }
        public static void Destroy(Object obj) { }
        public static void DestroyImmediate(Object obj) { }
        public static void Destroy(Object obj, float t) { }
        public static T Instantiate<T>(T original) where T : Object { return original; }
        public static T Instantiate<T>(T original, Transform parent) where T : Object { return original; }
        public static T FindObjectOfType<T>() where T : Object { return null; }
        public static bool operator ==(Object a, Object b)
        {
            bool an = ReferenceEquals(a, null);
            bool bn = ReferenceEquals(b, null);
            if (an || bn) return an && bn;
            return ReferenceEquals(a, b);
        }
        public static bool operator !=(Object a, Object b) { return !(a == b); }
        public override bool Equals(object other) { return Object.Equals(this, other as Object); }
        public override int GetHashCode() { return base.GetHashCode(); }
        public override string ToString() { return name; }
    }

    public class Component : Object
    {
        public GameObject gameObject { get; internal set; }
        public Transform transform { get { return gameObject != null ? gameObject.transform : null; } }
        public string tag { get; set; }
        public T GetComponent<T>() where T : class { return null; }
        public T GetComponentInChildren<T>() where T : class { return null; }
        public T GetComponentInChildren<T>(bool includeInactive) where T : class { return null; }
        public T GetComponentInParent<T>() where T : class { return null; }
        public bool CompareTag(string other) { return false; }
    }

    public class Behaviour : Component
    {
        public bool enabled { get; set; }
    }

    public class MonoBehaviour : Behaviour
    {
        public Coroutine StartCoroutine(IEnumerator routine) { return null; }
        public void StopCoroutine(Coroutine c) { }
    }

    public class Coroutine : YieldInstruction { }
    public class YieldInstruction { }
    public class WaitForSeconds : YieldInstruction
    {
        public WaitForSeconds(float seconds) { }
    }

    public class Transform : Component
    {
        public Vector3 position { get; set; }
        public Vector3 localPosition { get; set; }
        public Quaternion rotation { get; set; }
        public Quaternion localRotation { get; set; }
        public Vector3 eulerAngles { get; set; }
        public Vector3 localEulerAngles { get; set; }
        public Vector3 localScale { get; set; }
        public Vector3 scale { get; set; }
        public Transform parent { get; set; }
        public int childCount { get { return 0; } }
        public Vector3 up { get { return Vector3.up; } }
        public Vector3 forward { get { return Vector3.forward; } }
        public Vector3 right { get { return Vector3.right; } }
        public void SetParent(Transform p) { }
        public void SetParent(Transform p, bool worldPositionStays) { }
        public Transform GetChild(int index) { return null; }
        public Transform Find(string n) { return null; }
        public void Translate(Vector3 v) { }
        public void Rotate(Vector3 v) { }
        public void LookAt(Transform target) { }
    }

    public class GameObject : Object
    {
        public Transform transform { get; internal set; }
        public bool activeSelf { get { return true; } }
        public bool activeInHierarchy { get { return true; } }
        public string tag { get; set; }
        public LayerMask layerMask { get; set; }
        public int layer { get; set; }
        public GameObject(string name) { this.name = name; transform = new Transform(); transform.gameObject = this; }
        public GameObject() : this("") { }
        public void SetActive(bool value) { }
        public T AddComponent<T>() where T : Component, new() { return new T(); }
        public T GetComponent<T>() where T : class { return null; }
        public T GetComponentInChildren<T>() where T : class { return null; }
        public T GetComponentInChildren<T>(bool includeInactive) where T : class { return null; }
        public T GetComponentInParent<T>() where T : class { return null; }
        public static GameObject CreatePrimitive(PrimitiveType type) { return new GameObject(); }
        public static GameObject Find(string name) { return null; }
    }

    public class ScriptableObject : Object { }

    public struct LayerMask
    {
        public int value;
        public static implicit operator int(LayerMask m) { return m.value; }
        public static implicit operator LayerMask(int v) { return new LayerMask { value = v }; }
    }

    // ---------------- primitives & renderers ----------------
    public enum PrimitiveType { Sphere = 0, Capsule = 1, Cylinder = 2, Cube = 4, Plane = 8, Quad = 16 }
    public enum LightType { Spot = 0, Directional = 1, Point = 2 }
    public enum LightShadows { None = 0, Hard = 1, Soft = 2 }
    public enum CameraClearFlags { Skybox = 1, SolidColor = 2, Depth = 3, Nothing = 4 }
    public enum ShadowCastingMode { Off = 0, On = 1, ShadowsOnly = 2, TwoSided = 3 }

    public class Material : Object
    {
        public Material(Shader shader) { }
        public Color color { get; set; }
        public void SetColor(string name, Color value) { }
        public void SetFloat(string name, float value) { }
        public void SetTexture(string name, Texture value) { }
        public Texture mainTexture { get; set; }
    }

    public class Shader : Object
    {
        public static Shader Find(string name) { return new Shader(); }
    }

    public class Texture : Object { }
    public class Texture2D : Texture
    {
        public Texture2D(int width, int height) { }
        public void SetPixel(int x, int y, Color c) { }
        public void SetPixels32(Color32[] pixels) { }
        public void Apply() { }
    }

    public class Renderer : Component
    {
        public Material material { get; set; }
        public Material sharedMaterial { get; set; }
        public ShadowCastingMode shadowCastingMode { get; set; }
        public bool receiveShadows { get; set; }
        public bool enabled { get; set; }
    }

    public class MeshFilter : Component { }
    public class MeshRenderer : Renderer { }
    public class Collider : Component
    {
        public bool isTrigger { get; set; }
        public Bounds bounds { get { return new Bounds(); } }
        public Material sharedMaterial { get; set; }
        public bool enabled { get; set; }
    }
    public class BoxCollider : Collider
    {
        public Vector3 center { get; set; }
        public Vector3 size { get; set; }
        public bool centered { get; set; }
    }
    public class SphereCollider : Collider
    {
        public Vector3 center { get; set; }
        public float radius { get; set; }
    }
    public enum CapsuleDirection { X = 1, Y = 2, Z = 3 }
    public class CapsuleCollider : Collider
    {
        public Vector3 center { get; set; }
        public float radius { get; set; }
        public float height { get; set; }
        public CapsuleDirection direction { get; set; }
    }

    public class CharacterController : Collider
    {
        public float height { get; set; }
        public float radius { get; set; }
        public Vector3 center { get; set; }
        public float slopeLimit { get; set; }
        public float stepOffset { get; set; }
        public float skinWidth { get; set; }
        public bool isGrounded { get { return true; } }
        public struct MoveResult { public Vector3 movedPosition; }
        public MoveResult Move(Vector3 motion) { return new MoveResult(); }
    }

    public class Camera : Behaviour
    {
        public static Camera main { get { return null; } }
        public float fieldOfView { get; set; }
        public float nearClipPlane { get; set; }
        public float farClipPlane { get; set; }
        public CameraClearFlags clearFlags { get; set; }
        public Color backgroundColor { get; set; }
        public float aspect { get { return 1.78f; } }
        public Transform transform { get { return base.transform; } }
    }

    public class Light : Behaviour
    {
        public LightType type { get; set; }
        public Color color { get; set; }
        public float intensity { get; set; }
        public LightShadows shadows { get; set; }
        public float shadowStrength { get; set; }
        public float range { get; set; }
        public float spotAngle { get; set; }
    }

    // ---------------- animation (legacy component + clips) ----------------
    public class AnimationClip : Object
    {
        public float frameRate { get; set; }
        public bool legacy { get; set; }
        public float length { get { return 1f; } }
        public void SetCurve(string path, Type type, string propertyName, AnimationCurve curve) { }
        public void SetCurve(GameObject target, AnimationCurve curve, string propertyName) { }
        public void ClearCurves() { }
        public void EnsureQuaternionContinuity() { }
    }

    public class AnimationState
    {
        public float time { get; set; }
        public float weight { get; set; }
        public float speed { get; set; }
        public float length { get { return 1f; } }
        public bool loop { get; set; }
        public bool isPlaying { get { return true; } }
        public string name { get { return ""; } }
        public void Play() { }
        public void Stop() { }
    }

    public class Animation : Behaviour
    {
        public void AddClip(AnimationClip clip, string name) { }
        public void Play(string name) { }
        public AnimationState this[string name] { get { return new AnimationState(); } }
        public float speed { get; set; }
    }

    public enum AnimatorControllerParameterType { Float = 0, Int = 1, Bool = 2, Trigger = 3 }
    public class AnimatorControllerParameter
    {
        public string name { get; set; }
        public AnimatorControllerParameterType type { get; set; }
    }
    public class RuntimeAnimatorController : Object { }
    public class AnimatorController : RuntimeAnimatorController { }
    public class Animator : Behaviour
    {
        public RuntimeAnimatorController runtimeAnimatorController { get; set; }
        public void SetFloat(string name, float value) { }
        public void SetFloat(string name, float value, float deltaTime) { }
        public void SetFloat(string name, float value, float damping, float deltaTime) { }
        public void SetBool(string name, bool value) { }
        public void CrossFade(string stateName, float transitionDuration) { }
        public void Play(string stateName) { }
        public float GetFloat(string name) { return 0f; }
    }

    // ---------------- physics ----------------
    public struct RaycastHit
    {
        public float distance;
        public Vector3 point;
        public Vector3 normal;
        public Collider collider;
        public Transform transform;
    }

    public enum QueryTriggerInteraction { UseGlobal = 0, Collide = 1, Ignore = 2, None = 3 }

    public static class Physics
    {
        public static bool Raycast(Vector3 origin, Vector3 direction, out RaycastHit hitInfo) { hitInfo = new RaycastHit(); return false; }
        public static bool Raycast(Vector3 origin, Vector3 direction, out RaycastHit hitInfo, float maxDistance) { hitInfo = new RaycastHit(); return false; }
        public static bool Raycast(Vector3 origin, Vector3 direction, out RaycastHit hitInfo, float maxDistance, int layerMask) { hitInfo = new RaycastHit(); return false; }
        public static bool Raycast(Vector3 origin, Vector3 direction, out RaycastHit hitInfo, float maxDistance, int layerMask, QueryTriggerInteraction queryTriggerInteraction) { hitInfo = new RaycastHit(); return false; }
    }

    // ---------------- input ----------------
    public enum KeyCode { None = 0, A = 97, B = 98, C = 99, D = 100, E = 101, F = 102, G = 103, H = 104, I = 105, J = 106, K = 107, L = 108, M = 109, N = 110, O = 111, P = 112, Q = 113, R = 114, S = 115, T = 116, U = 117, V = 118, W = 119, X = 120, Y = 121, Z = 122, Space = 32, Escape = 27, LeftArrow = 276, RightArrow = 275, UpArrow = 273, DownArrow = 274 }
    public enum TouchPhase { Began = 0, Moved = 1, Stationary = 2, Ended = 3, Canceled = 4 }
    public struct Touch
    {
        public int fingerId;
        public TouchPhase phase;
        public Vector2 position;
        public Vector2 deltaPosition;
    }

    public static class Input
    {
        public static bool touchSupported { get { return false; } }
        public static int touchCount { get { return 0; } }
        public static Touch GetTouch(int index) { return new Touch(); }
        public static float GetAxis(string axisName) { return 0f; }
        public static float GetAxisRaw(string axisName) { return 0f; }
        public static bool GetButton(string buttonName) { return false; }
        public static bool GetButtonDown(string buttonName) { return false; }
        public static bool GetKey(KeyCode key) { return false; }
        public static bool GetKeyDown(KeyCode key) { return false; }
        public static bool GetMouseButton(int button) { return false; }
        public static bool GetMouseButtonDown(int button) { return false; }
        public static Vector3 mousePosition { get { return Vector3.zero; } }
        public static Vector3 mouseScrollDelta { get { return Vector3.zero; } }
    }

    // ---------------- misc ----------------
    public static class Time
    {
        public static float deltaTime { get { return 0.016f; } }
        public static float time { get { return 0f; } }
        public static float unscaledDeltaTime { get { return 0.016f; } }
        public static float timeScale { get; set; }
    }

    public static class Debug
    {
        public static void Log(object message) { }
        public static void LogWarning(object message) { }
        public static void LogError(object message) { }
        public static void LogException(Exception e) { }
    }

    public static class Application
    {
        public static string persistentDataPath { get { return "/tmp"; } }
        public static int targetFrameRate { get; set; }
        public static bool isEditor { get { return false; } }
    }

    public static class Screen
    {
        public static int width { get { return 1280; } }
        public static int height { get { return 720; } }
    }

    public enum ScreenOrientation { Portrait = 0, PortraitUpsideDown = 1, LandscapeLeft = 2, LandscapeRight = 3, AutoRotation = 4 }

    public static class Random
    {
        public static float Value { get { return 0f; } }
        public static int Range(int minInclusive, int maxExclusive) { return minInclusive; }
        public static float Range(float minInclusive, float maxExclusive) { return minInclusive; }
    }

    public static class Resources
    {
        public static T GetBuiltinResource<T>(string path) where T : Object { return null; }
        public static T Load<T>(string path) where T : Object { return null; }
    }

    public class Font : Object
    {
        public FontStyle style { get; set; }
    }
    public enum FontStyle { Normal = 0, Bold = 1, Italic = 2, BoldAndItalic = 3 }

    public static class PlayerPrefs
    {
        public static int GetInt(string key, int defaultValue) { return defaultValue; }
        public static void SetInt(string key, int value) { }
        public static float GetFloat(string key, float defaultValue) { return defaultValue; }
        public static void SetFloat(string key, float value) { }
        public static string GetString(string key, string defaultValue) { return defaultValue; }
        public static void SetString(string key, string value) { }
        public static bool HasKey(string key) { return false; }
        public static void DeleteKey(string key) { }
        public static void DeleteAll() { }
        public static void Save() { }
    }

    public class RenderSettings
    {
        public static Color ambientLight { get; set; }
        public static UnityEngine.Rendering.AmbientMode ambientMode { get; set; }
    }

    public class Rect
    {
        public Rect(float x, float y, float w, float h) { }
        public Rect(Vector2 min, Vector2 max) { }
        public Vector2 position { get; set; }
        public Vector2 size { get; set; }
    }

    public class Sprite : Object
    {
        public static Sprite Create(Texture2D texture, Rect rect, Vector2 pivot) { return new Sprite(); }
    }

    public class AudioListener : Behaviour { }

    public static class RectTransformUtility
    {
        public static bool RectangleContainsScreenPoint(UnityEngine.UI.RectTransform rect, Vector2 screenPoint, Camera cam) { return false; }
        public static bool ScreenPointToLocalPointInRectangle(UnityEngine.UI.RectTransform rect, Vector2 screenPoint, Camera cam, out Vector2 localPoint) { localPoint = Vector2.zero; return false; }
    }

    // ---------------- attributes ----------------
    public class SerializeField : Attribute { }
    public class HeaderAttribute : Attribute { public HeaderAttribute(string header) { } }
    public class TooltipAttribute : Attribute { public TooltipAttribute(string tooltip) { } }
    public class RangeAttribute : Attribute { public RangeAttribute(float min, float max) { } }
    public class RequireComponent : Attribute { public RequireComponent(Type t) { } }
    public class DisallowMultipleComponent : Attribute { }
    public class AddComponentMenu : Attribute { public AddComponentMenu(string menuName) { } }
    public class SpaceAttribute : Attribute { public SpaceAttribute() { } public SpaceAttribute(float h) { } }
}

namespace UnityEngine.Rendering
{
    public enum AmbientMode { Flat = 0, Trilight = 1, Skybox = 2 }
}

// ---------------- uGUI ----------------
namespace UnityEngine.Events
{
    public delegate void UnityAction();
    public class UnityEvent
    {
        public void AddListener(UnityAction call) { }
        public void RemoveListener(UnityAction call) { }
    }
}

namespace UnityEngine.UI
{
    using UnityEngine.Events;

    public class Graphic : MonoBehaviour
    {
        public Color color { get; set; }
        public bool raycastTarget { get; set; }
    }

    public class Canvas : Behaviour
    {
        public enum RenderMode { ScreenSpaceOverlay = 0, ScreenSpaceCamera = 1, WorldSpace = 2 }
        public RenderMode renderMode { get; set; }
        public int sortingOrder { get; set; }
    }

    public class CanvasScaler : MonoBehaviour
    {
        public enum ScaleMode { ConstantPixelSize = 0, ScaleWithScreenSize = 1, ConstantPhysicalSize = 2 }
        public ScaleMode uiScaleMode { get; set; }
        public Vector2 referenceResolution { get; set; }
        public float matchWidthOrHeight { get; set; }
    }

    public class GraphicRaycaster : MonoBehaviour { }

    public class RectTransform : Transform
    {
        public Vector2 anchorMin { get; set; }
        public Vector2 anchorMax { get; set; }
        public Vector2 pivot { get; set; }
        public Vector2 anchoredPosition { get; set; }
        public Vector2 sizeDelta { get; set; }
        public Vector2 offsetMin { get; set; }
        public Vector2 offsetMax { get; set; }
    }

    public class Image : Graphic
    {
        public Sprite sprite { get; set; }
    }

    public enum TextAnchor { UpperLeft = 0, UpperCenter = 1, UpperRight = 2, MiddleLeft = 3, MiddleCenter = 4, MiddleRight = 5, LowerLeft = 6, LowerCenter = 7, LowerRight = 8 }
    public enum HorizontalWrapMode { Wrap = 0, Overflow = 1 }
    public enum VerticalWrapMode { Truncate = 0, Overflow = 1 }

    public class Text : Graphic
    {
        public Font font { get; set; }
        public string text { get; set; }
        public int fontSize { get; set; }
        public TextAnchor alignment { get; set; }
        public FontStyle fontStyle { get; set; }
        public HorizontalWrapMode horizontalOverflow { get; set; }
        public VerticalWrapMode verticalOverflow { get; set; }
    }

    public class ButtonClickedEvent : UnityEvent { }

    public class Button : MonoBehaviour
    {
        public Graphic targetGraphic { get; set; }
        public ButtonClickedEvent onClick { get { return new ButtonClickedEvent(); } }
    }

    public class EventSystem : MonoBehaviour
    {
        public static EventSystem current { get { return null; } }
        public bool IsPointerOverGameObject() { return false; }
        public bool IsPointerOverGameObject(int pointerId) { return false; }
    }

    public class BaseInputModule : Behaviour { }
    public class StandaloneInputModule : BaseInputModule { }
    public class TouchInputModule : BaseInputModule { }
}

namespace UnityEngine.EventSystems
{
}

// ---------------- editor ----------------
namespace UnityEditor
{
    using UnityEngine;

    public class MenuItem : Attribute
    {
        public MenuItem(string itemName) { }
    }

    public static class EditorUtility
    {
        public static void DisplayDialog(string title, string message, string ok) { }
        public static void DisplayDialog(string title, string message, string ok, string cancel) { }
    }

    public static class AssetDatabase
    {
        public static bool IsValidFolder(string path) { return false; }
        public static string CreateFolder(string path, string newName) { return ""; }
        public static void Refresh() { }
        public static void SaveAssets() { }
        public static string GenerateUniqueAssetPath(string path) { return path; }
    }

    public static class PlayerSettings
    {
        public static string productName { get; set; }
        public static string applicationIdentifier { get; set; }
        public static string companyName { get; set; }
        public static ScreenOrientation defaultInterfaceOrientation { get; set; }
        public static class Android
        {
            public static AndroidArchitecture targetArchitectures { get; set; }
        }
    }

    [Flags]
    public enum AndroidArchitecture { None = 0, ARM = 2, ARMv7 = 4, ARM64 = 8, X86 = 16, X86_64 = 32 }
}

namespace UnityEditor.SceneManagement
{
    using UnityEngine;

    public struct Scene
    {
        public string path;
        public string name;
    }

    public enum NewSceneSetup { EmptyScene = 0, DefaultGameObjects = 1 }
    public enum NewSceneMode { Single = 0, Additive = 1 }

    public static class EditorSceneManager
    {
        public static Scene NewScene(NewSceneSetup setup, NewSceneMode mode) { return new Scene(); }
        public static void SaveScene(Scene scene, string path) { }
        public static bool OpenScene(string path) { return true; }
    }

    public static class Selection
    {
        public static GameObject activeGameObject { get; set; }
    }
}
